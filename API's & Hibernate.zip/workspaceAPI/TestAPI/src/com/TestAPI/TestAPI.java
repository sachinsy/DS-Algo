package com.TestAPI;

import com.ProjectAPI.*;
public class TestAPI {

	public static void main(String[] args) {
		
int SUM=API.add(5, 7);
System.out.println(SUM);
	}

}
