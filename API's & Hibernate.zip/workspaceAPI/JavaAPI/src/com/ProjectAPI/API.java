package com.ProjectAPI;

public class API {

	public static int add(int a,int b){
		System.out.println("API is being used");
		System.out.println("Hello");
		return a+b;
	}
}
