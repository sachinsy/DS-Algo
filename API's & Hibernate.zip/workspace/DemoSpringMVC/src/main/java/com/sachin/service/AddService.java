package com.sachin.service;

public class AddService {

	public int add(int a,int b) {
		// TODO Auto-generated constructor stub
	
		return a+b;
	}
}
