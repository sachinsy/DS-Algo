package com.maven;

public class App {
public String name(){
	return "name";
}
}
