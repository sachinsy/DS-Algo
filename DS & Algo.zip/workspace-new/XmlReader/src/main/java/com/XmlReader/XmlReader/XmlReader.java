package com.XmlReader.XmlReader;

import java.util.Scanner;

import com.sun.xml.xsom.XSComplexType;
import com.sun.xml.xsom.XSContentType;
import com.sun.xml.xsom.XSModelGroup;
import com.sun.xml.xsom.XSParticle;
import com.sun.xml.xsom.XSSchema;
import com.sun.xml.xsom.XSTerm;

public class XmlReader {
	public static void printElements(String complexType){
		XSSchema xsSchema=null;
	    XSComplexType xsComplexType = xsSchema.getComplexType("BUConnectingFP");
	    XSContentType xsContentType = xsComplexType.getContentType();
	    XSParticle particle = xsContentType.asParticle();
	    if(particle != null){
	        XSTerm term = particle.getTerm();
	        if(term.isModelGroup()){
	            XSModelGroup xsModelGroup = term.asModelGroup();
	            XSParticle[] particles = xsModelGroup.getChildren();
	            for(XSParticle p : particles ){
	                XSTerm pterm = p.getTerm();
	                if(pterm.isElementDecl()){ //xs:element inside complex type
	                    System.out.println(pterm);
	                }
	            }
	        }
	    }
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s=new Scanner(System.in);
		String complexType=s.next();
		XmlReader.printElements(complexType);
	}

}
