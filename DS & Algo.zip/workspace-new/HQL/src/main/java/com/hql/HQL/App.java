package com.hql.HQL;

import java.util.List;
import java.util.Random;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import org.hibernate.service.ServiceRegistry;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cf=new Configuration().configure().addAnnotatedClass(Student.class);
        ServiceRegistry sr=new StandardServiceRegistryBuilder().applySettings(cf.getProperties()).build();
        SessionFactory sf=cf.buildSessionFactory(sr);
        Session session=sf.openSession();
        session.beginTransaction();
        Random r=new Random();
        
        
       /* for(int i=1; i<=50;i++){
        Student s=new Student();
        s.setRollno(i);
        s.setName("Name "+i);
        s.setMarks(r.nextInt(100));
   
        session.save(s);
        }*/
        
        Query q=session.createQuery("from Student where marks=71");
        List<Student> students=q.list();
        for(Student s:students){
        	System.out.println(s);
        }
        
        //q.uniqueResult();
      
       
        
        session.getTransaction().commit();
        
        
        
    }
}
