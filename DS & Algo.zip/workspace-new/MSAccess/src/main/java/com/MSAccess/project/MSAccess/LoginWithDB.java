package com.MSAccess.project.MSAccess;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.*;


class Crud{
	static String DBurl="jdbc:ucanaccess://C://Users//sachiny//Documents//Database2.accdb";
	public static void read(){
		try {
			Connection con=DriverManager.getConnection(DBurl);
			String sql= "select * from Table1";
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				int id=rs.getInt("ID");
				String FirstName=rs.getString("FirstName");
				String LastName=rs.getString("LastName");
				java.sql.Date DOB=rs.getDate("DOB");
				//String DOB=rs.getString("DOB");
				String Username=rs.getString("Username");
				String Password=rs.getString("Password");
				String Email=rs.getString("Email");

				System.out.println(FirstName+" "+LastName+" "+DOB+" "+
						" "+Username+" "+Password+" "+Email);

				con.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	public static void create(){
		try {
			//String dob="05-10-1986";
			java.util.Date dob=new java.util.Date("05-Oct-86");			
			java.sql.Date DOB=new java.sql.Date(dob.getTime());
			
			Connection con=DriverManager.getConnection(DBurl);
			String sql="insert into Table1 (FirstName, LastName, DOB, Username, Password, Email)values( ?, ?, ?, ?, ?, ?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, "Sunil");
			ps.setString(2, "Yadav");
			ps.setDate(3, DOB);
			ps.setString(4, "sunily");
			ps.setString(5, "password");
			ps.setString(6, "sunily@gmail.com");
			
			ps.executeUpdate();
			con.close();
				//System.out.println("Properly inserted"+rs);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void delete(){
		try {
			Connection con=DriverManager.getConnection(DBurl);
			String sql="Delete from Table1 where FirstName=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, "Sunil");
			ps.executeUpdate();
			con.close();
			//System.out.println("Deleted");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void update(){
		try {
			Connection con=DriverManager.getConnection(DBurl);
			String sql="Update Table1 SET Username='RENUY' where FirstName=? ";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, "Renu");
			ps.executeUpdate();
			System.out.println("Updated");
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
public class LoginWithDB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Crud c=new Crud();
		//c.create();
		
		//c.delete();
		c.update();
		c.read();



	}

}
