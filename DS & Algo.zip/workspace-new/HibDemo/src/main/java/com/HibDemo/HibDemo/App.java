package com.HibDemo.HibDemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.Service;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class App 
{
	public static void main( String[] args )
	{
		//System.out.println( "Hello World!" );


		Laptop lp=new Laptop();
		lp.setLid(1);
		lp.setLname("Dell");

		Student s=new Student();
		s.setRollno(101);
		s.setSmarks(58);
		s.setSname("Susheel");
		s.getLaptop().add(lp);
		
		lp.getSt().add(s);


		Configuration cf=new Configuration().configure().addAnnotatedClass(Student.class).addAnnotatedClass(Laptop.class);
		ServiceRegistry reg=new ServiceRegistryBuilder().applySettings(cf.getProperties()).buildServiceRegistry();	
		SessionFactory sf=cf.buildSessionFactory(reg);
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		session.save(lp);
		session.save(s);
		tx.commit();
		System.out.println(s);
		System.out.println(lp);
	}
}
