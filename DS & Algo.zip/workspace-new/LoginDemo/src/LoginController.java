import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		System.out.println("1");
		response.setContentType("text/HTML");
		PrintWriter out=response.getWriter();
		String uname=request.getParameter("uname");
		String pass=request.getParameter("pass");
		
		if(uname.equals("Sachin") && pass.equals("sachin")){
			out.println("Welcome!!! \n"+uname);
			HttpSession session=request.getSession(true);
			session.setAttribute("uname", uname);
			session.setMaxInactiveInterval(30);
			response.sendRedirect("home.jsp");
		}
		else{
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			out.print("<H1>You have entered wrong user name or password");
			rd.include(request, response);
		}
	}

}
