import java.util.Scanner;

public class PenaltyShootout {

    public static void main(String[] args) {

        String teamOne = "Team A";
        String teamTwo = "Team B";

        int teamOneGoals = 0;
        int teamTwoGoals = 0;

        for (int balls = 0; balls < 5; balls++) {
            teamOneGoals += kickTheBall(teamOne);
            teamTwoGoals += kickTheBall(teamTwo);
            System.out.println(teamOne + " " + teamOneGoals + " - " + teamTwoGoals + " " + teamTwo);
        }

        if (teamOneGoals == teamTwoGoals) {
           // System.out.println("____________________________");
            System.out.println("It's a tie! It's a tie! We're going to have more rounds of shootout, " +
                    "first one to score goal wins the FINAL!!!");
           // System.out.println("_____________________________");
        }

        while (teamOneGoals == teamTwoGoals) {
            teamOneGoals += kickTheBall(teamOne);
            teamTwoGoals += kickTheBall(teamTwo);
            System.out.println(teamOne + " " + teamOneGoals + " - " + teamTwoGoals + " " + teamTwo);
        }

       // System.out.println("*********************************");
        if (teamOneGoals > teamTwoGoals) {
            System.out.println("YESSS!!! " + teamOne + " wins the FIFA World Cup, What a Game to win here.");
            System.out.println("Thank you everyone for joining us! Bye Bye!");

        } else {
            System.out.println("OMG!!! " + teamTwo + " beat the "+teamOne+" side to win the FIFA World Cup, " +
                    "What a Game to win here.");
            System.out.println("Thank you everyone for joining us! Bye Bye!");
        }
      //  System.out.println("*********************************");

      //  System.out.println("          ____________________");
       // System.out.println("          |    FINAL SCORE    |");
       // System.out.println("          |===================|");
        System.out.println("         "+ teamOne + " " + teamOneGoals + " - " + teamTwoGoals + " " + teamTwo );
      //  System.out.println("          |___________________|");

    }

    private static int kickTheBall(String team) {
        int goal = Math.random() > 0.5 ? 1 : 0;
        if (goal > 0) System.out.println(team + " shoots!");
        else System.out.println(team + " missed!");
        return goal;
    }

}
