import java.util.*;
class reverse{
	public int reverse(int n){
		int rev=0;
		while(n!=0){
			int d=n%10;
			rev=rev*10+d;
			n=n/10;
		}
		return rev;
	}
	
}
public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the no");
int n=s.nextInt();
reverse r=new reverse();
int pal=r.reverse(n);
if(n==pal){
	System.out.println("palin");
}
else System.out.println("not palin");
	}

}
