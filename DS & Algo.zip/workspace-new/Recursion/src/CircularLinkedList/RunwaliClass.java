package CircularLinkedList;

public class RunwaliClass {

	public static void main(String[] args) {
		CircularLinkedlIST cll=new CircularLinkedlIST();
		cll.insertAtStart(20);
		cll.insertAtStart(30);
		cll.insertAtEnd(5);
		cll.insertAtEnd(40);
		cll.insertAtStart(1);
		/*cll.display();
		cll.deleteAtStart();
		cll.display();	
		cll.insertAtStart(2);*/
		cll.display();
		//cll.deleteAtEnd();
		//cll.display();
	}

}
