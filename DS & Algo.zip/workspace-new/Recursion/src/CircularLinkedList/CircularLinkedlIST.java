package CircularLinkedList;

import java.util.NoSuchElementException;

public class CircularLinkedlIST {
	Node last,head;
	int length=1;
	public int length(){
		return length;
	}
	public boolean isEmpty(){
		return length==0;
	}
	public void insertAtStart(int data){
		Node node=new Node();
		node.data=data;
		node.next=null;

		if(last==null){
			last=node;
			last.next=last;
		}
		else{
			node.next=last.next;
			last.next=node;
		}
		//last.next=node;
		length++;
	}

	public void insertAtEnd(int data){
		Node node=new Node();
		node.data=data;
		node.next=null;
		if(last==null){
			last=node;
			last.next=last;
		}
		else{
			node.next=last.next;
			last.next=node;
			last=node;
		}
		length++;
	}

	public void deleteAtStart(){
		if(isEmpty()){
			throw new NoSuchElementException("CLL is already empty");
		}
		Node n=last.next;
		if(last.next==last){
			last=null;				
		}
		else{
			last.next=n.next;
			n.next=null;
		}

		length--;
	}
	/*public void deleteAtEnd(){
		if(isEmpty()){
			throw new NoSuchElementException("CLL is already empty");
		}
		Node n=last.next;
		if(last.next==last){
			last=null;
		}
		else{
			while(n.next!=last.next){
				n=n.next;
			}
			n.next=last.next;
			last.next=null;
			length--;
		}
	}*/
	public void display(){
		Node n=last.next;	
		while(n!=last) {
			System.out.print(n.data+"\t");
			//System.out.println(n.next);
			n=n.next;
		}
		System.out.println(n.data+"\t");
		//System.out.println(n.next);
	}
}
