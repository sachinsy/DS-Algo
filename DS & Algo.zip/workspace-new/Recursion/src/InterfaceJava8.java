
public class InterfaceJava8 implements A,B{

	@Override
	public void add() {
		// TODO Auto-generated method stub
		B.super.add();
	}
	public static void main(String[] args) {
		
		//InterfaceJava8 obj=new InterfaceJava8();
		A obj=new InterfaceJava8();
		obj.add();
		A.sub1();
	}

	

}
