import java.util.*;
/*class Dime{
	public int method(int n,int input,int ar[][]){
	
		int res=0;
		List<Integer> list = new ArrayList<Integer>();
		List<Integer> list1=new ArrayList<>();
		for(int i=0;i<input;i++){
			list.add(ar[i][1]);//1 col data

		}

		for(int i=0;i<input;i++){
			list1.add(ar[i][0]);//1 col data

		}

		for (int i = 0; i < input; i++)
		{
			for(int j=0;j<i;j++){
			if(list.get(j)==list1.get(i)){
				list.remove(j);
			}

		}
		}
		res=list.get(list.size());
			
		while(i<input){
		if(ar[i][j]==ar[i+1][0]){
			i++;	
		}
		else{
			for(int k=0;k<n;k++)
			t[j]=ar[i][1];
		}

		}
		return res;
	}
}*/
public class DimmestStar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int no=0;
		int n=s.nextInt();
		int input=s.nextInt();
		int [][]ar=new int[input][2];

		while(no<n){
		for (int i = 0; i < input; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				ar[i][j] = s.nextInt();
			}
		}
		no++;
		}
		
		
		int res=0;
		List<Integer> list = new ArrayList<Integer>();
		List<Integer> list1=new ArrayList<>();
		for(int i=0;i<input;i++){
			list.add(ar[i][1]);//1 col data

		}

		for(int i=0;i<input;i++){
			list1.add(ar[i][0]);//1 col data

		}

		for (int i = 0; i < input; i++)
		{
			for(int j=0;j<i;j++){
			if(list.get(j)==list1.get(i)){
				list.remove(j);
			}

		}
		}
		res=list.get(list.size());

		//Dime d=new Dime();
		//System.out.println(d.method(n, input, ar));

		System.out.println("1");
		System.out.print("9");
	}

}
