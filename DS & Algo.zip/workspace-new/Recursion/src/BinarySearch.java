import java.util.*;
class Sort{
	public void arrange(int ar[],int n){
		int temp=0;
		for(int i=0;i<ar.length;i++){
			for(int j=i+1;j<ar.length;j++)
			if(ar[i]>=ar[j]){
				temp=ar[i];
				ar[i]=ar[j];
				ar[j]=temp;
			}
		}
	}
}
class Dundho{
	public int dundho(int ar[],int ele,int l,int h){
		int m=(l+h)/2;
		if(h>=l){
			if(ele==ar[m])
				return m;
			if(ele<ar[m])
				return dundho(ar,ele,l,m-1);
			else return dundho(ar, ele, m+1, h);
		}
		return -1;
	}
}
public class BinarySearch {

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the no of elements");
		int n=s.nextInt();
		System.out.println("Enter the array");
		int a[]=new int[n];
		for(int i=0;i<n;i++){
			a[i]=s.nextInt();
		}
		Sort srt=new Sort();
		srt.arrange(a, n);
		System.out.println("Element to be searched");
		int ele=s.nextInt();
		
		Dundho srch=new Dundho();
		if(srch.dundho(a, ele, 0, n-1)==-1){
			System.out.println("Element not found");
		}
		else System.out.println("Element found");

	}

}
