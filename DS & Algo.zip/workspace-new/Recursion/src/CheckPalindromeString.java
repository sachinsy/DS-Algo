import java.util.*;
class CheckPalindrome{
	public String CheckPalindrome(String str){
		ArrayList<Character> al=new ArrayList<>();
		for(int i=0;i<str.length();i++){
			if(al.contains(str.charAt(i))){
				al.remove((Character)str.charAt(i));
			}
			else al.add(str.charAt(i));
		}
		if((str.length()%2==0 && al.isEmpty()) || (str.length()%2==1 && al.size()==1)){
			return "true";
		}
		else return "false";
	}
}
public class CheckPalindromeString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner src=new Scanner(System.in);
		System.out.println("Enter String");
		String str=src.next();
		CheckPalindrome cp=new CheckPalindrome();
		System.out.println(cp.CheckPalindrome(str));
		
	}

}
