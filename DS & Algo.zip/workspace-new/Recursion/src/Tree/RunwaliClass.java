package Tree;

public class RunwaliClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Node root=null;
		BinaryTree bt=new BinaryTree();
		root=bt.createBinaryTree(root,8);
		root=bt.createBinaryTree(root,3);
		root=bt.createBinaryTree(root,2);
		root=bt.createBinaryTree(root,5);
		root=bt.createBinaryTree(root,10);
		root=bt.createBinaryTree(root,9);
		root=bt.createBinaryTree(root,11);
		
		System.out.println("Preorder Traversal");
		bt.preorder(root);
		System.out.println("\n"+"Iterative Preorder");
		bt.iterativePre(root);
		System.out.println("\n"+"Postorder Traversal");
		bt.postorder(root);
		/*System.out.println("\n"+"Iterative Postorder Traversal");
		bt.IterativePost(root);*/
		System.out.println("\n"+"Iterative Inorder");
		bt.iterativeInorder(root);
		System.out.println("\n"+"Inorder Traversal");
		bt.inorder(root);
		System.out.println("\n"+"Levelwise Traversal");
		bt.levelwise(root);
	}

}
