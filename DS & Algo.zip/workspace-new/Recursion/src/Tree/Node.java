package Tree;

public class Node {

	int data;
	Node left;
	Node right;
}
