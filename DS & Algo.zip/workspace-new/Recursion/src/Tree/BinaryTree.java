package Tree;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class BinaryTree {
	Node root;
	public Node createNode(int data){
		Node node=new Node();
		node.data=data;
		node.left=null;
		node.right=null;

		return node;
	}
	public Node createBinaryTree(Node node,int data){

		if(node==null){
			return createNode(data);
		}
		else if(data<node.data){
			node.left=createBinaryTree(node.left, data);
		}
		else if(data>node.data){
			node.right=createBinaryTree(node.right, data);
		}

		return node;
	}

	public void preorder(Node node){

		if(node==null){
			return;
		}
		else{
			System.out.print(node.data+"\t");
			preorder(node.left);
			preorder(node.right);
		}
	}
	
	public void iterativePre(Node node){
		if(node==null){
			return;
		}
		else{
			Stack<Node> s=new Stack();
			s.push(node);
			while(!s.isEmpty()){
				Node n=s.pop();
				System.out.print(n.data+"\t");
				if(n.right!=null){
					s.push(n.right);
				}
				if(n.left!=null){
					s.push(n.left);
				}
			}
		}
	}
	
	public void iterativeInorder(Node node){
		if(node==null){
			return;
		}
		else{
			Stack<Node> s=new Stack();
			Node n=node;
			while(!s.isEmpty() || n!=null){
				if(n!=null){
					s.push(n);
					n=n.left;
				}else{
					n=s.pop();
					System.out.print(n.data+"\t");
					n=n.right;
				}
			}
		}
	}
	
/*	public void IterativePost(Node node){
		if(node == null){
			return;
		}
		else{
			Stack<Node> s=new Stack<>();
			Node n=node;
			while(!s.isEmpty() || n.left!=null){
				if(n!=null){
					s.push(n);
					n=n.left;
					if(n.left!=null){
						
					}
				}else{
					n=s.pop();
					if(n.right!=null){
						n=n.right;
						System.out.print(n.right+"\t");
					}
					System.out.print(n.data+"\t");
					n=n.right;
				}
			}
					
		}
	}
*/
	public void postorder(Node node){
		if(node==null){
			return;
		}
		else{
			postorder(node.left);
			postorder(node.right);
			System.out.print(node.data+"\t");
		}
	}
	
	
	public void inorder(Node node){
		if(node==null){
			return;
		}
		else{
			inorder(node.left);
			System.out.print(node.data+"\t");
			inorder(node.right);
		}
	}
	
	public void levelwise(Node node){
		if(node==null){
			return;
		}
		else{
			Queue<Node> queue=new LinkedList();
			queue.add(node);
			while(!queue.isEmpty()){
				Node n=queue.remove();
				System.out.print(n.data+"\t");
				if(n.left!=null){
					queue.add(n.left);
					//System.out.print(n.data+"\t");
				}
				if(n.right!=null){
					queue.add(n.right);
					//System.out.print(n.data+"\t");
				}
			}
		}
	}
}
