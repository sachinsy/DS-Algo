import java.util.*;
class oCount{
	public void oddCount(String s){
		char a[]=s.toCharArray();
		for(int i=0;i<s.length();i++){
			if(i%2!=0 && a[i]!=' '){
				System.out.print(a[i]+" ");
			}
		}
	}
}
public class oddCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner src=new Scanner(System.in);
oCount o=new oCount();
System.out.println("enter a string");
String s=src.nextLine();
o.oddCount(s);

	}
}
