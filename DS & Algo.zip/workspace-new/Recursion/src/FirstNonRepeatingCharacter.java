import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.logging.Logger;
class NonRepChar{	

	public static int method(String str){
		final int NO_OF_CHAR=256;
		int index=0;
		char count[]=new char[NO_OF_CHAR];		
		for(int i=0;i<str.length();i++){
			count[str.charAt(i)]++;
			//System.out.println(count);
		}
		//int max=count[str.charAt(0)];
		for(int j=0;j<str.length();j++){
			if(count[str.charAt(j)]==1){
				//max=count[str.charAt(j)];
				index=j;
				break;
			}
		}
		return index;
	}
}
public class FirstNonRepeatingCharacter {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Scanner src=new Scanner(System.in);
		
		String str="geeksforgeeks";
		NonRepChar rep=new NonRepChar();
		System.out.println("First non repeating char is "+str.charAt(rep.method(str)));

		
	}

}
