
public interface B {

	default void add(){
		System.out.println("Addition of Interface B is possible");
	}
}
