import java.util.*;
class Swap{
	public void SwapWithoutUsingVar(int a, int b){
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("a= "+a+" b= "+b);
	}
}
public class SwapwithoutVar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.print("a= ");
		int a=s.nextInt();
		System.out.print("b= ");
		int b=s.nextInt();
		Swap sw=new Swap();
		sw.SwapWithoutUsingVar(a, b);
	}

}
