class Sac{
	public void character(){
		System.out.println("A");
	}
}
class Sach extends Sac{
	
	public void character(){
		System.out.println("B");
	}
}
public class Coderbyte2 extends Sac  {
	static int a=10;
	public  void GroupDecode(){
	 int a=200;
	System.out.println(a);
		
	}
	public void character(){
		System.out.println("c");
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sac cb2=new Sach();
//Coderbyte2 cb2=new Coderbyte2();
		//cb2.GroupDecode();
		
		cb2.character();
		
		
	}

}
