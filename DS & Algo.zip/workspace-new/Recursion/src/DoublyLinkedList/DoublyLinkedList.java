package DoublyLinkedList;

public class DoublyLinkedList {
	Node head,tail;
	int length;
	/*public DoublyLinkedList(){
		this.head=null;
		this.tail=null;
		this.length=0;
	}
	 */
	public boolean isEmpty(){
		return length==0;//head==null
	}

	public int length(){
		return length;
	}


	public void insertAtStart(int data){
		Node node=new Node();
		node.data=data;
		if(isEmpty()){
			tail=node;
		}
		else{
			head.previous=node;
		}
		node.next=head;
		head=node;
		length++;

	}

	//insertAtLast
	public void insert(int data){
		Node node=new Node();
		node.data=data;
		if(isEmpty()){
			head=node;
		}
		else{
			tail.next=node;
		}
		node.previous=tail;
		tail=node;
		length++;
	}

	public void insertAt(int index,int data){
		Node node=new Node();
		node.data=data;
		if(index==0){
			insertAtStart(data);
		}
		else if(index==length-1){
			insert(data);
		}
		else{
			Node n=head;
			Node n1=null;
			for(int i=0;i<index-1;i++){
				n=n.next;
			}
			n1=n.next;
			n.next=node;
			node.previous=n;
			node.next=n1;
		}

	}
	public void deleteAtStart(){
		if(length==0){
			System.out.println("List is empty");
		}
		else{
			Node n=head.next;
			head.next=null;
			n.previous=null;
			head=n;
		}
	}
	public void deleteAtLast(){
		if(length==0){
			System.out.println("List is empty");
		}
		else{
			Node n=tail.previous;
			n.next=null;
			tail.previous=null;
			tail=n;
		}
	}
	public void deleteAt(int index){
		if(index==0){
			deleteAtStart();
		}
		else if(index==length){
			deleteAtLast();
		}
		else{
			Node n1=null;
			Node n=head;
			for(int i=0;i<index-1;i++){
				n=n.next;
			}
			n1=n.next.next;
			n1.previous=n.next;
			n.next=n1;		
		}
	}
	public int search(int ele){
		Node n=head;
		while(n!=null){	
			if(ele==n.data){
				return ele;
			}else{
				n=n.next;
			}
		}
		return -1;
	}

	public void nodeAtPosition(int index) throws NullPointerException{
		if(index==length+1){
			throw new NullPointerException("Node is not present");
		}
		Node n=head;
		for(int i=0;i<index;i++){
			n=n.next;
		}
		System.out.println(n.data);
	}
	public void displayForward(){
		if(head==null){
			return;
		}
		Node n=head;
		while(n!=null){
			System.out.print(n.data+" ");
			n=n.next;
		}
		System.out.print("Null");
	}

	public void sortAsc(){
		Node first=head;
		Node second=null;
		while(first.next!=null){
			second=first.next;
			while(second!=null){
				if(first.data>second.data){
					int t=first.data;
					first.data=second.data;
					second.data=t;
				}
				second=second.next;
			}
			first=first.next;
		}
	}
	public void displayBackward(){
		if(tail==null){
			return;
		}
		Node n=tail;
		while(n!=null){
			System.out.print(n.data+" ");
			n=n.previous;
		}
		System.out.print("Null");
	}
}
