package DoublyLinkedList;
import java.util.*;
public class RunwaliClass {

	public static void main(String[] args) throws NullPointerException{
		// TODO Auto-generated method stub
		Scanner src=new Scanner(System.in);
		DoublyLinkedList dll=new DoublyLinkedList();

		dll.insert(50);
		dll.insert(60);
		dll.insert(20);
		dll.insertAtStart(10);
		dll.insertAt(2, 30);
		dll.displayForward();
		System.out.println("\n");
		//dll.deleteAtStart();
		//dll.deleteAtLast();
		//dll.deleteAt(1);
		//dll.displayForward();

		dll.sortAsc();
		dll.displayForward();
		System.out.println("\n");
		System.out.println("Enter index to get the data");
		int index=src.nextInt();
		try{
			dll.nodeAtPosition(index);}
		catch(NullPointerException e){
			System.out.println("Node is absent");
		}
		/*System.out.println("Enter node to be searched");
		int ele=src.nextInt();
		if(dll.search(ele)==-1){
			System.out.println("Node not found");
		}
		else System.out.println("Node found");
		 */
		//System.out.println(dll.length());
		//dll.displayBackward();
	}

}
