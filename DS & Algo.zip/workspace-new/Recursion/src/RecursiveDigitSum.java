import java.math.BigInteger;
import java.util.*;
class superDigit {

	static int calculateSum(long no){
		int u=0,sum=0;
		BigInteger b1;
		while(no>0){
			// u=(b1.intValue())%10;
			u=(int)(no%10);
			sum+=u;
			no=no/10;
		}
		return sum;
	}
	static int count(int no){
		int count=0;
		while(no>0){
			count++;
			no=no/10;
		}
		return count;
	}
	static int superDigit(String n, int k) {
		int count=0;
		long No=Long.parseLong(n);
		// BigInteger bi=new BigInteger(n);
		int actualNo=calculateSum(No);
		//System.out.println(actualNo);
		actualNo=actualNo*k;
		int bk=actualNo;
		count=count(actualNo);
		// System.out.println(count);
		while(count>1){
			actualNo= calculateSum(actualNo);
			int count1=count(actualNo);
			if(count==count1){
				actualNo= calculateSum(actualNo);
			}
			count--;
			//break;
		}


		return actualNo;

	}
}

public class RecursiveDigitSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		superDigit s=new superDigit();
		System.out.println(s.superDigit("861568688536788", 100000));
	}

}
