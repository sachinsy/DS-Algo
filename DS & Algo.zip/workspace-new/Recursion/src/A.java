

import java.math.*;
class BadaInteger {
    public int solution(int[] A) {
        // write your code in Java SE 8
        int res=1,finalres=0;
        BigInteger bi=BigInteger.valueOf(1);
       // BigInteger b=BigInteger.valueOf(1);
        for(int i=0;i<A.length;i++){
            bi=bi.multiply(BigInteger.valueOf(A[i]));
        }
        int compareValue=bi.compareTo(BigInteger.valueOf(0));
        if(compareValue==-1){
            return finalres+=-1;
        }
        if(compareValue==1){
            return finalres+=1;
        }
        else return finalres=0;
    }
}


public interface A {

	default void add(){
		System.out.println("Addition of Interface A is possible");
	}
	static void sub1(){
		System.out.println("subtraction of A");
	}
}