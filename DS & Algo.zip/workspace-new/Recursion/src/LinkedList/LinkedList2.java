package LinkedList;

public class LinkedList2 {
	Node head;
	public void insert(int data){
		Node node=new Node();
		node.data=data;
		node.next=null;

		if(head==null){
			head=node;
		}
		else{
			Node n=head;
			while(n.next!=null){
				n=n.next;
			}
			n.next=node;
		}
	}

	public void insertAtStart(int data){
		Node node=new Node();
		node.data=data;
		node.next=null;
		node.next=head;
		head=node;
	}

	public void insertAt(int index,int data){
		Node node=new Node();
		node.data=data;
		node.next=null;

		if(index==0){
			insertAtStart(data);
		}

		else{
			Node n=head;
			for(int i=0;i<index-1;i++){
				n=n.next;
			}
			node.next=n.next;
			n.next=node;

		}
	}

	public void delete(int index){
		if(index==0){
			head.next=head;
		}
		else{
			Node n=head;
			Node n1=null;
			for(int i=0;i<index-1;i++){
				n=n.next;
			}
			n1=n.next;
			n.next=n1.next;
		}
	}

	public int checkElement(int ele){
		Node n=head;
		while(n!=null){
			if(ele==n.data){
				return ele;
			}
			else{
				n=n.next;
			}
		}
		return -1;
	}

	public void reverse(){

		Node pointer=head;
		Node prev=null;
		Node current=null;

		if(head==null){
			System.out.println("Linked list is empty");;
		}
		while(pointer!=null){
			current=pointer;
			pointer=pointer.next;
			current.next=prev;
			prev=current;
			head=current;
		}

	}

	
	
	//------------------Recursive way of reversing the linked list-----------
/*	public static Node reverseRecursive(Node head){

		if(head==null || head.next==null){
			return head;
		}
		Node temp=reverseRecursive(head.next);
		head.next.next=head;
		head.next=null;
		
		return temp;
	}*/


	public void getMiddleNode(){
		if(head==null){
			System.out.println("No element is there");
		}
		else{
			Node firstptr=head;
			Node secondptr=head;
			while(secondptr!=null && secondptr.next!=null){
				firstptr=firstptr.next;
				secondptr=secondptr.next.next; 
			}
			System.out.println("Middle element = "+firstptr.data);
		}
	}


	public void NthNodeFromLast(int index){
		Node resPtr=head;
		Node refPtr=head;
		int count=0;
		if(head==null){
			System.out.println("No element is there");
		}
		while(count<index){
			//resPtr=refPtr.next;
			refPtr=refPtr.next;
			count++;
		}
		while(refPtr!=null){
			refPtr=refPtr.next;
			resPtr=resPtr.next;
		}
		System.out.println(resPtr.data);
	}

	public void removeDuplicateSortedLL(){
		Node n=head;
		while(n!=null && n.next!=null){
			if(n.data==n.next.data){
				n.next=n.next.next;
			}
			else{
				n=n.next;
			}
		}
	}

	public void insertInSortedLL(int data){
		Node node=new Node();
		node.data=data;
		node.next=null;

		if(head==null){
			head=node;
		}
		else{
			Node n=head;
			Node temp=null;
			while(n!=null && n.data<node.data){
				temp=n;
				n=n.next;
			}

			temp.next=node;
			node.next=n;
		}
	}

	public void deleteNode(int key){
		Node n=head;
		Node n1=null;
		if(head==null){
			System.out.println("LL is empty");
		}
		else{
			while(n!=null && n.data!=key){
				n1=n;
				n=n.next;
			}
			if(n1==null) return;
			n1.next=n.next;
		}
	}

	public void llSize(){
		int c=0;
		Node n=head;
		while(n!=null){
			c++;
			n=n.next;	
		}
		System.out.println("Size of LL is "+c);
	}

	public void ascSort(){
		Node first=head;
		Node second=null;
		if(head==null){
			return;
		}
		while(first.next!=null){
			second=first.next;
			while(second!=null){
				if(first.data>second.data){
					int t=first.data;
					first.data=second.data;
					second.data=t;
				}
				second=second.next;
			}
			first=first.next;
		}
	}
	/* =====================Deletion of a node without having head=====================
	 *  public void deleteNodeNoHead( Node node){
		 Node temp=node.next;
		 node.data=temp.data;
		 node.next=temp.next;
	 }
	 */
	public void show(){
		Node n=head;
		while(n.next!=null){
			System.out.print(n.data+"\t");
			n=n.next;
		}
		System.out.println(n.data+"\t");
	}

	public int detectCycle(){
		Node slowptr=head,fastptr=head;
		while(slowptr!=null && fastptr!=null && fastptr.next!=null){
			slowptr=slowptr.next;
			fastptr=fastptr.next.next;
			if(slowptr==fastptr){
				//removeCycle(fastptr);
				System.out.println("Cycle detected");
				return 1;
			}
			else{
				System.out.println("Cycle Note detected");
				continue;
			}
		}
		return 0;
	}

	/*public void removeCycle(Node loop) {
		Node ptr1=loop,ptr2=loop;
		int c=1;
		while(ptr1.next!=ptr2){
			ptr1=ptr1.next;
			c++;
		}
		ptr1=head;
		ptr2=head;
		for(int i=0;i<c;i++){
			ptr2=ptr2.next;
		}
		while(ptr2!=ptr1){
			ptr1=ptr1.next;
			ptr2=ptr2.next;
		}
		while(ptr2.next!=ptr1){
			ptr2=ptr2.next;
		}
		ptr2=null;

	}
	 */
}
