package LinkedList;

import java.util.*;
public class PalindromeCheck {
	
	public boolean isPalindrome(PNode head) {
		boolean isPalin = true;
		PNode n = head;
		Stack<Integer> stack = new Stack<Integer>();

		while (n!= null) {
			stack.push(n.data);
			n = n.next;
		}

		while (head != null) {
			int i = (int) stack.pop();
			if (i == head.data) {
				isPalin = true;
			} else {
				isPalin = false;
				break;
			}
			head = head.next;
		}

		return isPalin;
	}
	
}
