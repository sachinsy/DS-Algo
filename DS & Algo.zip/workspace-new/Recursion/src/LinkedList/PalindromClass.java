package LinkedList;

import java.util.Stack;

class PNode{
	PNode next;
	int data;
	PNode(int d){
		next=null;
		data=d;
	}	
}

public class PalindromClass {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PNode one=new PNode(1);
		PNode two=new PNode(2);
		PNode three=new PNode(1);
		one.next=two;
		two.next=three;
	
		
		PalindromeCheck check=new PalindromeCheck();
		boolean condition=check.isPalindrome(one);
			System.out.println("is Palindrome ? = " +condition);
			
			
		}

}
