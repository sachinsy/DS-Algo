package LinkedList; 
class CycleDetect{
	Node head;
	public void insertAtStart(int data){
		Node node=new Node();
		node.data=data;
		node.next=null;
		/* if(head==null){
    	head=node;
    }
    else{*/
		node.next=head;
		head=node;
	}


	public void display(){
		Node n=head;
		while(n.next!=null){
			System.out.println(n.data+" ");
			n=n.next;
		}
		System.out.println(n.data+" ");
	}
	public int detect(){
		Node first_ptr=head,sec_ptr=head;
		while(first_ptr!=null && sec_ptr!=null && sec_ptr.next!=null){
			first_ptr=first_ptr.next;
			sec_ptr=sec_ptr.next.next;
			if(first_ptr==sec_ptr){
				removeCycle(first_ptr);
				System.out.print("Cycle Detected");
				return 1;
			}
			else {
				System.out.println("Cycle is not found");
				continue;
			}
		}
		return 0;
	}

	public void removeCycle(Node loop) {
		Node ptr1=loop,ptr2=loop;
		int c=1;
		while(ptr1.next!=ptr2){
			ptr1=ptr1.next;
			c++;
		}
		ptr1=head;
		ptr2=head;
		for(int i=0;i<c;i++){
			ptr2=ptr2.next;
		}
		while(ptr2!=ptr1){
			ptr1=ptr1.next;
			ptr2=ptr2.next;
		}
		while(ptr2.next!=ptr1){
			ptr2=ptr2.next;
		}
		ptr2.next=null;

	}

}

public class CycleCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CycleDetect cd=new CycleDetect();
		cd.insertAtStart(20);
		cd.insertAtStart(10);
		cd.insertAtStart(30);
		cd.insertAtStart(10);
		cd.head.next.next.next = cd.head;
		//cd.display();
		cd.detect();
		System.out.println("\nafter removing cycle ");
		cd.display();
	}

}
