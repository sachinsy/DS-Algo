package LinkedList;

public class Node {
	int data;
    Node next;	

}
