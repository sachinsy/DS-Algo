package LinkedList;

public class IntersectionPointOfLL {
	Node head1,head2;

	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
		}
	}

	public int getCount(Node node){
		int c=0;
		Node n=node;
		while(n!=null){
			c++;
			n=n.next;
		}
		return c;
	}

	public int getNode(){
		int c1=getCount(head1);
		int c2=getCount(head2);
		int d;
		if(c1>c2){
			d=c1-c2;
			return getIntersectionNode(d,head1,head2);
		}
		else{
			d=c2-c1;
			return getIntersectionNode(d, head2, head1);
		}
	}

	public int getIntersectionNode(int d, Node head12, Node head22) {
		Node current1=head12;
		Node current2=head22;
		for(int i=0;i<d;i++){
			if(current1==null){
				return -1;
			}
			current1=current1.next;
		}
		while(current1!=null && current2!=null){
			if(current1.data==current2.data){
				return current1.data;
			}
			current1=current1.next;
			current2=current2.next;
		}

		return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntersectionPointOfLL il=new IntersectionPointOfLL();
		il.head1=new Node(5);
		il.head1.next=new Node(10);
		il.head1.next.next=new Node(15);
		il.head1.next.next.next=new Node(31);
		il.head1.next.next.next.next=new Node(25);


		il.head2=new Node(23);
		il.head2.next=new Node(31);
		il.head2.next.next=new Node(25);

		System.out.println("The insection node "+il.getNode());
	}

}
