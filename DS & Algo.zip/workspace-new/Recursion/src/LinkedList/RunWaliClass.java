package LinkedList;
import java.util.*;

public class RunWaliClass {
	public static void main(String args[]){
		/*LinkedList list=new LinkedList();

		list.insert(10);
		list.insert(40);
		list.insert(12);
		list.insert(45);
		//	list.insert(50);

		list.insertAtStart(30);
		list.insertAt(0, 33);
		list.deleteAt(2);
		list.show();*/
		
		//-------------Pract1----------------------
		
		/*LinkedList1 list=new LinkedList1();
		list.insert(10);
		list.insert(20);
		list.insertAtStart(40);
		list.inserAt(2, 30);
		list.inserAt(0, 5);
		list.delete(0);
		list.show();*/
		
		//----------------Pract2--------------------
		
		
		LinkedList2 list=new LinkedList2();
		list.insert(10);
		list.insert(10);
		list.insert(30);
		list.insertAtStart(5);
		list.insertAt(1, 1);
		list.insertAt(0,1);
		//list.delete(2);
		list.show();	
		System.out.println("Reverse Linked List is:");
		list.reverse();
	
		list.show();
		
		System.out.println("Sorted linked list");
		list.ascSort();
		list.show();		
		//list.llSize();
		list.getMiddleNode();
		list.delete(5);
		list.show();
		list.getMiddleNode();
		list.NthNodeFromLast(2);
		
		System.out.println("Inserting Element appropriately in sorted LL");
		list.insertInSortedLL(7);
		list.show();

		/*Scanner s=new Scanner(System.in);
		System.out.println("Enter element to be searched in the LL");
		int ele=s.nextInt();
		if(list.checkElement(ele)==-1){
			System.out.println(ele+" Node not found");
		}
		else{
			System.out.println(ele+" Node found");
		}
*/
		System.out.println("Removing duplicates from sorted LL");
		list.removeDuplicateSortedLL();
		list.show();
		
		System.out.println("Removing node based on their value in sorted LL");
		list.deleteNode(5);
		list.show();
		

	
	}
	}
