package Stack;

public class Stack {

	int stack[]=new int[5];
	int top=0;
	public void push(int data){
		if(isFull()){
			System.out.println("Stack is overflowing");
		}
		else{
			stack[top]=data;
		    top++;
		}
	}
	

	public int pop(){
		int data=0;
		top--;
		if(isEmpty()){
			System.out.println("Stack is underflowing");
		}
		else{
		data=stack[top];
		stack[top]=0;
		}
		return data;
	}
	

	public int peek(){
		int data;
		data=stack[top-1];

		return data;
	}
	
	public int size(){
		return top;
	}
	
	public boolean isEmpty(){
		if(top==-1){
			return true;
		}
		else return false;	
	}
	
	public boolean isFull(){
		if(top==stack.length){
			return true;
		}
		else return false;
	}
	
	public void show(){
		for(int s: stack){
			System.out.print(s+" ");
		}
		System.out.println("\n");
	}

}
