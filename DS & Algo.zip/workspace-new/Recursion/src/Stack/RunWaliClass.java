package Stack;

public class RunWaliClass {

	public static void main(String[] args) {
		Stack s=new Stack();
		s.push(20);
		s.push(10);
		s.push(30);
		s.push(40);
		s.push(50);
		
		s.show();	
		//s.push(60);
		s.pop();
		s.show();
		
		/*s.pop();
		s.show();//50
		s.pop();
		s.show();//40
		s.pop();
		s.show();//30
		s.pop();
		s.show();//10
		s.pop();
		s.show();//20
		s.pop();
		------------Stack Underflow----------*/
		
		
/*		
	---------	Dynamic Array Stack--------------
		DStack ds=new DStack();
		ds.push(10);
		ds.show();
		ds.push(20);
		ds.show();
		ds.push(30);
		ds.show();
		ds.push(40);
		ds.show();
		ds.push(50);
		ds.show();
		
		ds.pop();
		ds.show();
		ds.pop();
		ds.show();
		ds.pop();
		ds.show();
		ds.pop();
		ds.show();
		*/

		
	}

}
