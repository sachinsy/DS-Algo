import java.util.*;
class Ulta2{
	public void reverse(String str){
		char a[]=str.toCharArray();
		int n=a.length;
		char b[]=new char[a.length];
		for(int i=0;i<a.length;i++){
			b[i]=a[n-1];
			n--;
		}

		System.out.println(b);
	}

	public void alternatigcharc(String str){
		char a[]=str.toCharArray();
		int n=a.length;
		char b[]=new char[a.length];
		for(int i=0;i<n;i++){
			if(i%2==0){
				b[i]=(char)(a[i]-32);
			}
			else {
				b[i]=a[i];
			}
		}
		System.out.println(b);
	}

	public void clockwiseRotation(int arr[]){
		
		int n=arr.length,t=arr[0];
		int b[]=new int[arr.length];

		for(int i=0;i<n-1;i++){
			arr[i]=arr[i+1];
		}
		arr[n-1]=t;
	}
	public void noOfRot(int arr[],int k){
		for(int i=0;i<k;i++){
			clockwiseRotation(arr);	
		}
	}

}
public class ReverseString {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ulta2 u=new Ulta2();

		u.reverse("abcd");
		u.alternatigcharc("sachin");
		int arr[]={1,2,3,4,5};
		int k=2;
		System.out.println(arr.length);
		u.noOfRot(arr, k);
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+"\t");
	}
	


}
