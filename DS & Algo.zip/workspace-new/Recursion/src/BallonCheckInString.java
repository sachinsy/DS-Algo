import java.util.*;
class Solution{
	public static void Solution(String str){
		
		HashMap<Character, Integer> hmap=new HashMap<>();
		hmap.put('B', 1);
		hmap.put('A', 1);
		hmap.put('L', 2);
		hmap.put('O', 2);
		hmap.put('N', 1);
		for(Map.Entry<Character,Integer> entry : hmap.entrySet()){
			System.out.println(entry.getKey()+"\t"+entry.getValue());

		}

		System.out.println("-------------------------");

		HashMap<Character, Integer> hm=new HashMap<>();

		for(int i=0;i<str.length();i++){
			if(hm.get(str.charAt(i))!=null){
				hm.put(str.charAt(i), hm.get(str.charAt(i))+1);
			}
			else{
				hm.put(str.charAt(i), 1);	
			}
		}
		int count=0;

	}
}
public class BallonCheckInString {

	public static void main(String[] args) {
		String str="BALLOONBAA";
		Solution s=new Solution();
		s.Solution(str);
	}


}
