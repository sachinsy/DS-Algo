import java.io.FileNotFoundException;
import java.io.IOException;

/*public final class Model{

	 final private int id;
	 final private String name;
	 
	public Model(int id, String name) {
		//super();
		this.id = id;
		this.name = name;
	}
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}*/
public class Model{
	void MethodA()throws FileNotFoundException{
		throw new RuntimeException();
	}
/*	void MethodB() throws NullPointerException{
		throw new IOException();
	}*/
	void MethodC() throws FileNotFoundException{
		MethodA();
		//MethodB();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	//	Model mod=new Model(1, "Gulfam");
		//Model mod1=new Model(1, "sachin");
		
		
		//System.out.println(mod.hashCode());
		//System.out.println(mod1.hashCode());
	int arr[]={1,2,3,4};
	
	
		
	}

	
	
	 
	 
	
}





