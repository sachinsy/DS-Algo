import java.util.*;
class Ulta{
	public void reverse(int n){
		int rev=0;
		while(n!=0){
			int u=n%10;
			rev=rev*10+u;
			n=n/10;
		}
		System.out.println(rev);
	}
}
public class Rev {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
int n=s.nextInt();
		Ulta u=new Ulta();
u.reverse(n);


	}

}
