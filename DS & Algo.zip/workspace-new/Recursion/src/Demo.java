import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
public class Demo {
	public String getInfo(){
		int a=2,b=3;
		for(int i=0;i<10;i++){
			if(a<b){
				System.out.println("hii");
				return "1";
			}
			else return "2";
		}
		return "3";
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
	/*	String url="jdbc:oracle:thin:@localhost:1552:xe";
		String username="sachin";
		String pass="abc123";
		String sql="" ;
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(url,username,pass);
			Statement stmt=con.createStatement();
			stmt.executeUpdate(sql);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
			Demo d=new Demo();
		System.out.println(d.getInfo());
		//d.s1();
		//d.s2();
	}
}


