import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

class TofindDuplicate{
	public static void TofindDuplicate(String s){
		int i=0,c=0,j=0;
		HashMap<Character, Integer> hm=new HashMap<>();
		while(s.charAt(i)!=-1){
			for(i=0;i<s.length();i++){
				if(s.charAt(i)==s.charAt(j+1)){
					hm.put(s.charAt(i),c++);
					j++;
				}
				else {
					hm.put(s.charAt(i),1);
				}
			}
		
			Iterator<Character> is=hm.keySet().iterator();
			while(is.hasNext()){
				Character str1=is.next();
				if(hm.get(str1)>1){
					hm.remove(str1);
					System.out.println("The word "+str1+" appeared "+hm.values() +" no of times");
				}
			}
		}
	}
}
public class DuplicateChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="abca";
		TofindDuplicate tf=new TofindDuplicate();
		tf.TofindDuplicate(s);

	}

}
