import java.util.*;
public class closesttoZero {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		HashMap<Integer, Integer> hmap=new HashMap<>();
		int ar[]={1,2,2,3,4};
		for(int i=0;i<ar.length;i++){
			if(hmap.containsKey(ar[i])){
				hmap.put(ar[i], hmap.get(ar[i])+1);
			
			}
			else{
				hmap.put(ar[i], 1);
			}
		}
		for(Map.Entry<Integer,Integer> entry : hmap.entrySet()){
			if(entry.getValue()==1){
				System.out.println(entry.getKey()+"\t"+entry.getValue());
				break;
			}
			if(entry.getValue()==0){
				System.out.println(entry.getKey());
				break;
			}
			
		}
	}

}
