import java.util.*;
class StringArray{
		public void StringArrayConcatenate(String str1,String str2){
			char s1[]=str1.toCharArray();
			char s2[]=str2.toCharArray();
			char res[]=new char[s1.length+s2.length];
			System.arraycopy(s1, 0, res, 0, s1.length);
			System.arraycopy(s2, 0, res, s1.length, s2.length);
			System.out.println(res);
		}
}
public class StringConcatenateWithoutUsingOPerator {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String str1=s.nextLine();
		String str2=s.nextLine();
		StringArray sa=new StringArray();
		sa.StringArrayConcatenate(str1, str2);

	}

}
