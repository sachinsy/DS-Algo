import java.util.*;
class Algo{
	public static int algoritham(int arr[]){
		int max_so_far=0,max_find=0;
		for(int i=0;i<arr.length;i++){
			max_so_far+=arr[i];

			if(max_so_far<0){
				max_so_far=0;
			}
			if(max_find<max_so_far){
				max_find=max_so_far;
			}
		}
		return max_find;
	}
}
public class Kadane {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner src=new Scanner(System.in);
		System.out.println("Enter the size");
		int n=src.nextInt();
		int a[]=new int[n];
		for(int i=0;i<n;i++){
			a[i]=src.nextInt();
		}
		Algo al=new Algo();
		System.out.println(al.algoritham(a));
	}

}
