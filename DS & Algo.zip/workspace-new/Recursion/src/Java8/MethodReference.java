package Java8;

class My {
	public void parse(){
		
	}
}

public class MethodReference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
