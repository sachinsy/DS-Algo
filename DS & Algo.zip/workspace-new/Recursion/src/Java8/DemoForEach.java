package Java8;

import java.util.Arrays;
import java.util.List;



public class DemoForEach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//This is till java 1.7 
		//---External loop 
		List<Integer> list=Arrays.asList(2,4,5,1,4);
		/*for(int i=0;i<list.size();i++){
			System.out.println(list.get(i));
		}*/
		//Java enhanced For loop
		/*for(int i:list){
			System.out.println(i);
		}*/
		
		//----Internal loop/iteration from java 1.8
		//Lambda Expression---forEach Loop
		list.forEach(i -> System.out.println(i));//	//below is the implementation of consumer interface
	}

}
