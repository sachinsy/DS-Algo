package Java8;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

import javax.swing.text.ZoneView;

public class DateTimeDemi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDateTime t= LocalDateTime.now(ZoneId.of("Asia/Atyrau"));
		System.out.println(t);
		for(String s:ZoneId.getAvailableZoneIds()){
			System.out.println(s);
		}
		
		//System.out.println(date);
		
	}

}
