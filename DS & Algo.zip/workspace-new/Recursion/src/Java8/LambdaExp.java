package Java8;

interface A{
	void show();
}
/*class Ext implements A{
	public void show(){
		System.out.println("Hello interface");
	}
}*/
public class LambdaExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
		A obj=new A()
		//annonymous inner class
		{
			public void show(){
			System.out.println("Hii from annonymous class to the interface");	
			}
		};
		obj.show();*/
		
		A obj;
		//Lambda Expression
		//below is the implementation of consumer interface
		obj=() ->{
			
			System.out.println("Hello interface A");
		};
		obj.show();
	}

}
