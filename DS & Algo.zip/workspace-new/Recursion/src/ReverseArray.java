import java.util.*;
class ReverseArr{
	public void reverseInNthTime(int a[]){
		int b[]=new int[a.length];
		int j=a.length;
		for(int i=0;i<a.length;i++){	
			b[j-1]=a[i];
			j--;
		}
		System.out.println("Reversed array is:");
		for(int i=0;i<b.length;i++){
			System.out.print(b[i]+" ");
		}
	
	}
}
public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the size of array");
int n=s.nextInt();
System.out.println("Give the array");
int a[]=new int[n];
for(int i=0;i<a.length;i++){
	a[i]=s.nextInt();
}
System.out.println("Given array is");
for(int i=0;i<a.length;i++){
	System.out.print(a[i]+" ");
}
System.out.println(" ");
ReverseArr r=new ReverseArr();
r.reverseInNthTime(a);

	}

}
