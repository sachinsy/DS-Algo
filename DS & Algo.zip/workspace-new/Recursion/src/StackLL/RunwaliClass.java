package StackLL;

public class RunwaliClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*StackLL sl=new StackLL();
		sl.push(8);
		sl.push(10);
		sl.push(20);
		sl.push(32);
		sl.display();
		System.out.println("\n");
		sl.pop();*/
		//sl.display();
		
		StackLinkedList sl=new StackLinkedList();
		sl.push(32);
		sl.push(20);
		sl.push(10);
		sl.push(8);
		sl.display();
		sl.pop();
		sl.display();
		sl.pop();
		sl.display();
		sl.pop();
		sl.display();
		sl.pop();
		sl.display();
		
	}

}
