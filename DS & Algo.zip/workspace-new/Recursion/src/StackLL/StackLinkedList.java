package StackLL;

import java.util.NoSuchElementException;

public class StackLinkedList {
	Node head;
	int top=0;
	public void push(int data){
		Node node=new Node();
		node.data=data;
		node.next=null;
		if(head==null){
			head=node;
			top++;
		}
		else{
			Node n=head;
			while(n.next!=null){
				n=n.next;
			}
			n.next=node;
			top++;
		}
	}
	
	public void pop(){
		int data;
		if(top==0 || head.next==null){
			System.out.println("Stack is empty");
		}
		else{
			Node n=head;
			while(n.next.next!=null){
				n=n.next;
			}
			top--;
			data=n.next.data;
			n.next=null;	
			System.out.println(data);
			
		}
	
	}
	public void display(){
		Node n=head;
		if(top==0){
			System.out.println("There is no element");
		}
		while(n.next!=null){
			System.out.print(n.data+"\t");
			n=n.next;
		}
		System.out.println(n.data+"\t");

	}
}
