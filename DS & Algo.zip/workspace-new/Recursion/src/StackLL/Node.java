package StackLL;

public class Node {
	int data;
	Node next;
}
