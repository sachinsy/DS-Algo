package StackLL;

public class StackLL {
	Node head,top;
	int length=0;
	public void push(int data){
		Node node=new Node();
		node.data=data;
		node.next=null;
		if(head==null){
			head=node;
		}
		else{
			Node n=head;
			node.next=n;
			head=node;
			top=node;
			length++;
		}

	}
	public int pop(){
		Node n=head;
		int result;
        result=top.data;
        top=top.next;
        length--;
        if(length==-1){
        	System.out.println("Stack is empty");
        }
        
        return result;
	}

	public void display(){
		Node n=head;
		while(n!=null){
			System.out.print(n.data+" ");
			n=n.next;
		}
		System.out.println(n.data);
	}
}
