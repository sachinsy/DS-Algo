import java.util.*;
import java.util.Map.Entry;
class Sachin{
	String name;
	int no;
	public Sachin(String name) {
		super();
		this.name = name;
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + no;
		return result;
	}
	
/*	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sachin other = (Sachin) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (no != other.no)
			return false;
		return true;
	}
	
*/
	 
	
}
public class HashMapBasic {

	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
	/*	HashMap<Integer,Integer> hm1=new HashMap<>();
		hm1.put(null, 10);
		hm1.put(null, 20);
		hm1.put(1, 10);
		hm1.put(null, 10);
		
		for(Map.Entry<Integer, Integer> entry: hm1.entrySet()){
			System.out.print(hm1.get(entry.getKey())+" "+hm1.get(entry.getValue())+"\n");
		}
		
		*/

		Sachin s=new Sachin("Sachin");
		Sachin s1=new Sachin("Sachin");
		Sachin s2=new Sachin("Saac");
		
		System.out.println(s.equals(s1));
		HashMap<Sachin,Integer> hm=new HashMap<>();
		hm.put(s, 100);
		hm.put(s1, 90);
		hm.put(s2, 110);
		
		System.out.println(hm.get(s));
		
		
		
	/*	Hashtable<Integer,Integer> ht=new Hashtable<>();
		ht.put(null, 1);
		System.out.println(ht.get(null));*/
	}

}
