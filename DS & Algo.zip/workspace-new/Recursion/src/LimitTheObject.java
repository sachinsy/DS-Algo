import java.util.*;
public class LimitTheObject {
	private static LimitTheObject watch;
	private static int countObject=0;
	private LimitTheObject(){
		countObject++;
	}
	
	
	public static LimitTheObject getInstance(){
		if(countObject<3){
			watch=new LimitTheObject();
		}
		return watch;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LimitTheObject obj1=LimitTheObject.getInstance();
		LimitTheObject obj2=LimitTheObject.getInstance();
		LimitTheObject obj3=LimitTheObject.getInstance();
		LimitTheObject obj4=LimitTheObject.getInstance();
		System.out.println(obj1);
		System.out.println(obj2);
		System.out.println(obj3); 
		System.out.println(obj4);
		
	}

}
