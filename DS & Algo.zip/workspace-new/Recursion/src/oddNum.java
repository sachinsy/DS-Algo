import java.util.Scanner;
class oCount1{
	public void oddCount(int a[]){
		//char a[]=s.toCharArray();
		
		for(int i=0;i<a.length;i++){
			if(i%2==0){
				System.out.print(a[i]+" ");
			}
		}
	}
}
public class oddNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner src=new Scanner(System.in);
		oCount1 o=new oCount1();
		System.out.println("enter  no");
		int a[]=new int[10];
		for(int i=0;i<a.length;i++){
			a[i]=src.nextInt();
		}
		o.oddCount(a);

	}

}
