import java.util.*;

class Recursion{
	 public long fact(long n){
		 if(n<0){
			 return -1;
		 }
	        if(n==0 || n==1){
	            return 1;
	        }
	        else return ((n)*fact(n-1));
	    }
}

public class Fact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s=new Scanner(System.in);
		 System.out.println("Enter no");
		 long n1=s.nextLong();
        Recursion r=new Recursion();
        System.out.println(r.fact(n1));
	}
	

}
