import java.lang.reflect.ReflectPermission;
import java.util.*;

class Search{
	public int search(int ar[],int n){
		for(int i=0;i<ar.length;i++){
			if(ar[i]==n){
				return 1;
			}

		}
		return -1;
	}
}

public class LinearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);

		/*   Set to normal array
		 * Set<Integer> set=new HashSet<>();
			for(int i=0;i<5;i++){
				set.add(i);
			}
			System.out.println(set);
			Object set1[]=set.toArray();
			for(int i=0;i<set1.length;i++)
			System.out.print(set1[i]+",");
			Iterable i;
		 */
		/*	String strin="abc";
			String str1="abc";
			String str2=new String("abc"); 	

			System.out.println("str1 ka id "+System.identityHashCode(str1));
			 System.out.println("str 2 ka id "+System.identityHashCode(str2));
			 System.out.println(System.identityHashCode("abc"));
			 System.out.println(System.identityHashCode(strin));
			//  System.out.println("Not matching");
		 */		
		System.out.println("Enter the no of elements");
		int no=s.nextInt();
		System.out.println("Enter elements");
		int a[]=new int[no];
		for(int i=0;i<a.length;i++){
			a[i]=s.nextInt();
		}
		System.out.println("Element to be searched");
		int fno=s.nextInt();
		Search s1=new Search();
		if(s1.search(a, fno)==-1){
			System.out.println("not found");
		}
		else System.out.println("Found");

	}

}
