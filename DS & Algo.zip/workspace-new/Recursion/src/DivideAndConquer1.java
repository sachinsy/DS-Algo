import java.util.*;
class Quick{
	public int partition(int ar[],int l,int h){
		int pivot=ar[h],i=l-1;
		for(int j=l;j<h;j++){
		if(ar[j]<=pivot){
			i++;
		   int t=ar[i];
			ar[i]=ar[j];
			ar[j]=t;
		}
		}
		
		int t=ar[i+1];
		ar[i+1]=ar[h];
		ar[h]=t;
		
		return i++;
	}
	
	public void orderwise(int ar[],int l,int h){
		if(l<h){
		int p = partition(ar,l,h);
		orderwise(ar, l, p-1);
		orderwise(ar, p+1, h);
		}
	}
	

static void printArray(int arr[]) 
{ 
    int n = arr.length; 
    for (int i=0; i<n; ++i) 
        System.out.print(arr[i] + " "); 
    System.out.println(); 
}
}

public class DivideAndConquer1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int ar[]=new int[n];
		for(int i=0;i<n;i++){
			ar[i]=s.nextInt();
		}
		Quick q=new Quick();
		q.orderwise(ar, 0, n-1);
		q.printArray(ar);

	}

}
