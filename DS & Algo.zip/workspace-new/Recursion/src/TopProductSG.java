import java.util.*;
class Base{
	public String s1="Base";
	public void method(){
		System.out.println("Base");
	}

	}
class Derived extends Base{
	public String s1="Derived";
	public void method(){
		System.out.println("Derived");
	}
}

public class TopProductSG {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner src=new Scanner(System.in);
		Base b=new Derived();
		System.out.println(b.s1);
		b.method();
		
        int i = 10 + + 11 - - 12 + + 13 - - 14 + + 15;        
        System.out.println(i);


	}

}
