import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

class NonRepeat{
	public void Nonrpeat(String Str){
		char[] ch=Str.toCharArray();
		int c=0;
		Map<Character, Integer> hm=new ConcurrentHashMap<Character, Integer>();
		for(int i=0;i<Str.length();i++){
			if(hm.containsKey(ch[i])){
				hm.put(ch[i],c++ );
			}
			else hm.put(ch[i], 1);
		}
		
		for(Map.Entry<Character,Integer> entry:hm.entrySet()){
		if(entry.getValue()==1){
			System.out.println("First non Repeat char is "+entry.getKey());
			break;
		}
		System.out.println("Don't have the non repeating character");
		}
		 
	}
}
public class NonRepeatChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String Str="sachin";
		NonRepeat np=new NonRepeat();
		np.Nonrpeat(Str);
	}

}
