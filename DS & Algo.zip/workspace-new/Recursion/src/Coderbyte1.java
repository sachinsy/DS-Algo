import java.util.Scanner;
import java.util.Vector;

public class Coderbyte1 {
	public static boolean search(int[] arr,int size,int value){
		for(int x=0;x<arr.length;x++){
			if(value==arr[x]){
				return true;
			}
		}

		return false;
	}

	public static String ArrayAddition(int arr[],int size){
		String res="";
		int value,total,index;
		int[] numberSkip=new int[arr.length];
		int max=arr[0],sum=0;
		for(int i=1;i<arr.length;i++){
			if(arr[i]>max){
				max=arr[i];
			}
		}
		for(int j=0;j<arr.length;j++){
			if(arr[j]==max){
				continue;
			}
			else{
				value=arr[j];
			}
			do{
				total=value;
				index=-1;
				for(int y=0;y<size;y++){
					if(y==1 || arr[y] == max || search(numberSkip,numberSkip.length,arr[y])){
						continue;
					}
					if(index==-1){
						index=y;
					}
					total +=arr[y];
					if(total==max){
						return "true";
					}
				}
				
			}while(numberSkip.length!=-2);
		}


		return "false";
	}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a[]={3,5,8,-1,12};
		int a1[]={1,2,3,4};
		System.out.println(ArrayAddition(a,a.length));

	}
}
