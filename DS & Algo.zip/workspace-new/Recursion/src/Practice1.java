import java.io.BufferedInputStream;
import java.util.*;
class Practice {
	public void method(int a,int b,int n){
		int sum=0,c=1;
		sum=a+b*c;
		System.out.print(sum+"\t");
		n--;
		while(n!=0){
			c=c*2;
			sum=sum+c*b;
			
			System.out.print(sum+"\t");
			n--;
		}
		
	}
}

class Practice2{
	public void method(int ar[],int n){
		for(int i=0;i<n;i++){
			for(int j=i+1;j<n;j++){
				if(ar[j]<ar[i]){
					int t=ar[j];
					ar[j]=ar[i];
					ar[i]=t;
				}
			}
		}
		/*for(int i=0;i<ar.length;i++){
			System.out.print(ar[i]+"\t");
		}*/
		int c=0;
		int count[]=new int[n];
		for(int i=1;i<ar.length;i++){
			for(int j=i+1;j<ar.length;j++){
				if(ar[i]==ar[j]){
				count[i]++;	
				}
			}
			c=c+(count[i]++/2);
		}
		System.out.print(c);
	}
}
public class Practice1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner src=new Scanner(System.in);
		while(src.hasNext()){
	      int a,b,n;
	      //for(int i=0;i<2;i++){
		 a=src.nextInt();
		 b=src.nextInt();
		 n=src.nextInt();
		//}
		Practice p=new Practice();
		p.method(a, b, n);
		}
		int n=src.nextInt();
		int ar[]=new int[n];
		for(int i=0;i<ar.length;i++){
			ar[i]=src.nextInt();
		}
		
		/*Practice2 p2=new Practice2();
		p2.method(ar, n);*/
	}


}