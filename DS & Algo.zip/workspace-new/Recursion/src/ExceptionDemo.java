import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ExceptionDemo {

	public static void main(String[] args)  {

		ExceptionDemo demo  = new ExceptionDemo();
		demo.fx();


	}

	public void fx() throws ArithmeticException
	{

		int a = 5;
		int b = 0;

		//FileReader file = new FileReader("");
		try{
			int c = a/b;
			System.out.println("Hello");
			System.out.println(c);

		}

			catch (ArithmeticException e) {
		e.printStackTrace();
	}

		System.out.println("hello 2");
	}


}
