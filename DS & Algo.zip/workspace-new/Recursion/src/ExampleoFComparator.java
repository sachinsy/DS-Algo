import java.util.*;

class Employee  implements Comparable<Employee>{
	private int id;
	private String name;
	private String doj;
	private int salary;


	public Employee(int id, String name, String doj, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.doj = doj;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", doj=" + doj + ", salary=" + salary + "]";
	}


	@Override
	public int compareTo(Employee emp) {
		// TODO Auto-generated method stub
		int esal=this.salary;
		if(esal>emp.salary){
			return 1;
		}
		else if(esal<emp.salary){
			return -1;
		}
		else return 0;
	}

}
public class ExampleoFComparator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee emp=new Employee(1,"Sachin","15/06/1997",30000 );
		Employee emp1=new Employee(2,"Sachin","12/05/1987",34000 );
		Employee emp2=new Employee(3,"Vijay","15/06/1995",30800 );
		Employee emp3=new Employee(4,"Name","10/05/1993",40000 );

		List<Employee> list=new ArrayList<Employee>();
		list.add(emp);
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		System.out.println(list);

		System.out.println("\n");
		List<Employee> list1=new ArrayList<Employee>();
		list1.add(emp);
		list1.add(emp1);
		list1.add(emp2);
		list1.add(emp3);
		Collections.sort(list);
		System.out.println(list);


		//Collections.sort(list);

		/*	System.out.println(emp);
		System.out.println(emp1);
		System.out.println(emp2);
		System.out.println(emp3);*/



	}


}
