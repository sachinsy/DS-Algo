package Queue;

public class Queue {

	int queue[]=new int[5];
	int size=0,front=0,rear=0;
	public void enQueue(int data){
		if(isFull()){
			System.out.println("\n"+"Queue is Full");
		}
		else{
			queue[rear]=data;
			rear=(rear+1)%5;//rear++  for linear queue
			size++;
		}
	}
	public int deQueue(){
		int data=0;
		if(isEmpty()){
			System.out.println("\n"+"Queue is empty");			
		}
		else{
			data=queue[front];
			queue[front]=0;
			front=(front+1)%5;
			size--;//front++ for linear queue
		}

		return data;
	}
	public int getSize(){
		return size;
	}
	public boolean isEmpty(){
		if(getSize()==0){
			return true;
		}
		else return false;
	}
	public boolean isFull(){
		if(queue.length==getSize()){
			return true;
		}
		else return false;
	}
	public void show(){

		for(int i=0;i<size;i++){
			System.out.print(queue[(front+i)%5]+" ");
		}
		System.out.println();
		for(int n: queue){
			System.out.print(n+" ");
		}
	}
}
