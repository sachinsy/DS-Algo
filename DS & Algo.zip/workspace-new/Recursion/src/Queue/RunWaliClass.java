package Queue;

public class RunWaliClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue q=new Queue();
		/*q.enQueue(20);
		q.enQueue(30);
		q.enQueue(10);
		q.enQueue(40);
		q.enQueue(50);
		q.show();
		q.deQueue();
		q.show();
		q.enQueue(1);*/
		//Problem with this queue is once it is full then after deleting some index value
		//and making the space and try enqueue once again then it's not possible...
		//it is resolved using circular queue.
		//So to make circular queue just do rear=rear%5 & front=front%5
		
		
		//q.enQueue(60);
		//q.show();

		/*q.deQueue();
		q.show();
		q.deQueue();
		q.show();
		q.deQueue();
		q.show();
		q.deQueue();
		*/
		q.enQueue(10);
		q.enQueue(20);
		q.enQueue(30);
		q.enQueue(40);
		
		q.deQueue();
		q.deQueue();
		
		q.enQueue(5);
		q.enQueue(6);
		
		q.enQueue(7);
		q.enQueue(8);
		q.show();

	}

}
