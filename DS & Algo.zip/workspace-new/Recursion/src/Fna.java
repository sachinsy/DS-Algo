import java.util.*;
class sum{
	public void add(int n){
		int a=0,b=1,c;
		System.out.print(a+" ");
		System.out.print(b+" ");
		
		for(int i=2;i<n;i++){
			c=a+b;
			a=b;
			b=c;
			System.out.print(c+" ");
		}
		
	}
}
public class Fna {
	public static void main(String args[]) {	
Scanner s=new Scanner(System.in);
int n=s.nextInt();
	sum s1=new sum();
s1.add(n);
 }
}
