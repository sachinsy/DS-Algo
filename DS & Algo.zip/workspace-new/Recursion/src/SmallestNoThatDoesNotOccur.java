import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
public class SmallestNoThatDoesNotOccur {

	public  static int solution(int []A){
		int res=0;
		//Set<Integer> set=IntStream.of(A).filter(i-> i>0).boxed().collect(Collectors.toList());
		Set<Integer> set=IntStream.of(A).boxed().filter(i-> i>0).collect(Collectors.toSet());
		for(int i=1;i<A.length;i++){
			if(!set.contains(i)){
				res= i;
				break;
			}
		}
		return res;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		
		int A[]={1,-1,3,4,5};
	
		
		System.out.println(solution(A));

	}

}
