import java.util.Arrays;

public class Pair {

	public static int[] twoSum(int[] nums, int target) { 
		int t[]=new int[2];
	
		int n=nums.length;
		//Arrays.sort(nums);
		int j=n-1,i=0;
		while(n>=0){		
			if(nums[i]+nums[j]==target){
				t[0]=i;
				t[1]=j;
				if(i>j){
					t[0]=j;
					t[1]=i;
				}
			}
			else if(nums[i]+nums[j]<target && target>0){
				i++;
			}
			else if(nums[i]+nums[j]>target && target>0){
				j--;	
			}
			else if(nums[i]+nums[j]<target && target<0){
				j--;
			}
			else if(nums[i]+nums[j]>target && target<0){
				i++;	
			}
			n--;
		}
		return t;
	}
	public static void main(String[] args) {
		
		int nums[]={-2,-7,7,-15};
		int target=0;
		int a[]=twoSum(nums, target);
		
		System.out.print("["+a[0]+",");
		System.out.print(a[1]+"]");
		
	
	}

}


