import java.util.*;
import java.util.stream.Collectors;
class WaterAccumulator{
	public int accumulator(int arr[],int n){
		int water=0;
		int left[]=new int[n];
		int right[]=new int[n];
		
		left[0]=arr[0];
		for(int i=1;i<n;i++){
			left[i]=Math.max(left[i-1], arr[i]);
		}
		
		right[n-1]=arr[n-1];
		for(int i=n-2; i>=0; i--){
			right[i]=Math.max(right[i+1], arr[i]);
		}
		
		for(int i=0;i<n;i++){
			water+=Math.min(left[i], right[i])-arr[i];
		}
		
		return water;
	}
}
public class WaterTrippingProblem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter size");
		int n=s.nextInt();
		int a[]=new int[n];
		System.out.println("Enter block nos");
		for(int i=0;i<a.length;i++){
			a[i]=s.nextInt();
		}
		WaterAccumulator wa=new WaterAccumulator();
		System.out.println(wa.accumulator(a, n));

	}

}
