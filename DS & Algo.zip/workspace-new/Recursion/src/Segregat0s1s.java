import java.util.*;
class Segregate{
	public void Segregate(int a[]){
		int c=0;
		for(int i=0;i<a.length;i++){
			if(a[i]==0)
				c++;
			}
			for(int j=0;j<c;j++){
				a[j]=0;
			}
			for(int k=c;k<a.length;k++){
				a[k]=1;
			}
		}
	}


public class Segregat0s1s {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the size");
int n=s.nextInt();
System.out.println("Enter the array");
int a[]=new int[n];
for(int i=0;i<n;i++){
	a[i]=s.nextInt();
}
System.out.println("After Segregation");
Segregate se=new Segregate();
se.Segregate(a);
for(int i=0;i<n;i++){
	System.out.print(a[i]+"\t");
}

	}

}
