class parent{
	int a=10;
	public void print(){
		System.out.println("parent");
	}
}
class child extends parent{
	int a=20;
	public void print(){
		System.out.println("child");
	}
}
class C extends child{
	public void print(){
		System.out.println("child");
	}
}
public class Bindings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parent p=new child();
	child c=new C();
		System.out.println(p.a);///Static binding
		p.print();//Dynamic binding

	}

}
