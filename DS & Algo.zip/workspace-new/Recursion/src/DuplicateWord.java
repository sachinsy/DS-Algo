import java.util.*;
class SeparateWord{
	public void SeparateWord(String str){
		HashMap<String, Integer> hm=new HashMap<>();
		String[] s=str.split(" ");
		for(String st:s){
			if(hm.get(st)!=null){
				hm.put(st, hm.get(st)+1);
			}
			else{
				hm.put(st, 1);	
			}
		}
		
		Iterator<String> is=hm.keySet().iterator();
		while(is.hasNext()){
			String str1=is.next();
			if(hm.get(str1)>1){
				System.out.println("The word "+str1+" appeared "+hm.get(str1) +" no of times");
			}
		}
	}
}
public class DuplicateWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String str=s.nextLine();
		SeparateWord sw=new SeparateWord();
		sw.SeparateWord(str);
		
	}
}
