import java.awt.print.Printable;
import java.util.*;
class InputArray{
	public int[] inputArray(int ar[]){
		int sum=1,k=0,n=ar.length;
		int b[]=new int [n];

		for(int i=0;i<ar.length;i++){
			for(int j=0;j<ar.length;j++){
				if(i!=j){
					sum=sum*ar[j];  //Time complexity will be O(n^2)
				}
			}
			b[i]=sum;
			sum=1;
		}

		return b;
	}
	public static void print(int ar[]){
		int n=ar.length;
		for(int i=0;i<n;i++){
			System.out.print(ar[i]+"\t");
		}
	}
}

public class Cuberootz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		InputArray ia=new InputArray();
		int ar[]=new int[]{1,2,3,4};
		int b[]=ia.inputArray(ar);
		ia.print(b);
	}

}
