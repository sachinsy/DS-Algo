import java.util.*;
class Jodo{
	public static void Jodo(int ar[],int li, int hi){
		if(li<hi){
			int m=(li+hi)/2;
			Jodo(ar,li,m);
			Jodo(ar,m+1,hi);
			JodoSort(ar,li,m,hi);
		}
	}
	
	public  static void JodoSort(int ar[],int li,int m,int hi){
		int j=m+1,i=li,k=0;
		int t[]=new int[hi-li+1];
		while(i<=m && j<=hi){
			if(ar[i]<=ar[j]){
				t[k++]=ar[i++];
			}
			else t[k++]=ar[j++];
		}
		while(i<=m){
			t[k++]=ar[i++];
		}
		while(j<=hi){
			t[k++]=ar[j++];
		}
		for(i=li;i<=hi;i++){
			ar[i]=t[i-li];
		}
	}

static void printArray(int arr[]) 
{ 
    int n = arr.length; 
    for (int i=0; i<n; ++i) 
        System.out.print(arr[i] + " "); 
    System.out.println(); 
}
}
public class DIvideAndConquer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int ar[]=new int[n];
		for(int i=0;i<n;i++){
			ar[i]=s.nextInt();
		}
		Jodo j=new Jodo();
		j.Jodo(ar, 0, n-1);
		j.printArray(ar);

	}

}
