package QueueLL;

public class RunwaliClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		QueueLL qll=new QueueLL();
		qll.add(32);
		qll.add(20);
		qll.add(10);
		qll.add(8);
		qll.display();
		
		qll.delete();
		qll.display();
		qll.delete();
		qll.display();
		qll.delete();
		qll.display();		
		qll.delete();
		qll.display();
	}

}
