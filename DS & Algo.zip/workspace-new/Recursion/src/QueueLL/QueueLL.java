package QueueLL;

import java.util.NoSuchElementException;

public class QueueLL {
	Node head;
	int front=0,rear=0;
	public void add(int data){
		Node node=new Node();
		node.data=data;
		node.next=null;

		if(head==null){
			head=node;
		}
		else{
			Node n=head;
			node.next=n;
			head=node;
			rear++;
		}
	}
	
	public void delete(){		
			Node n=head;
			head=head.next;
			System.out.println(n.data);
			n.next=null;
			front++;
	}
	public void display(){
		Node n=head;
		if(head==null)throw new NoSuchElementException("Queue is empty");
		while(n.next!=null){
			System.out.print(n.data+"\t");
			n=n.next;
		}
		System.out.println(n.data+"\t");
	}
}
