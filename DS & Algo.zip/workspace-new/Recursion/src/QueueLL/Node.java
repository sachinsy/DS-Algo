package QueueLL;

public class Node {
	Node next;
	int data;
}
