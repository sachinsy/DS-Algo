
public class Test implements Runnable {

	@Override
	public void run() {
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0 ; i<11; i++)
		{
			System.out.println(i+"> "+ Thread.currentThread().getName());
			
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		Thread t1 = new Thread(new Test(),"first thread");
		Thread t2 = new Thread(new Test(),"second thread");
		
		t1.start();
		
		t2.start();
	
		
	}

}
