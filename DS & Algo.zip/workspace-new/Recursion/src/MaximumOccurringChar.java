import java.util.*;
class MaxOccurChar{
	public void MaxOccur(String str){
		HashMap<String, Integer> hm=new HashMap<>();
		String a[]=str.split(" ");
		for(String s:a){
			if(hm.get(s)!=null){
				hm.put(s, hm.get(s)+1);
			}
			else hm.put(s, 1);
		}
		Iterator<String> is=hm.keySet().iterator();
		while(is.hasNext()){
			String st=is.next();
			if(hm.get(str)>1){
				System.out.println("Character "+st+" has occurrence of "+hm.get(st));
			}

		}
	}
}
public class MaximumOccurringChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="a a b a c d d";
		MaxOccurChar mc=new MaxOccurChar();
		mc.MaxOccur(str);
	}

}
