class Subh{
	Subh(int i,int j){
		System.out.println(i+j);
	}

}
public class PrivateConsttructor extends Subh{

	

	 PrivateConsttructor(int age,String name) {
		super(10,20);
		System.out.println("Hi");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	System.out.println(new PrivateConsttructor(1,"Sachin"));
	}

}
