import java.util.*;
class Pattern{
	/*public void Pattern1(int n){
		for(int i=1;i<n;i++){
			for(int j=1;j<=i;j++){
				System.out.print(i);
				System.out.print("");
			}
			System.out.println("");
		}
	}*/
	
	public void Pattern2(int n){
		for(int i=0;i<=n;i++){
			for(int j=i;j<n;j++)
				{
				System.out.print(" ");
		
				}
			for(int k=0;k<(2*i-1);k++)
			{
				System.out.print("*");
			}
			System.out.println(" ");
			
			}
	}
	

}

public class Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
int n=s.nextInt();
Pattern p=new Pattern();
p.Pattern2(n);
	}

}
