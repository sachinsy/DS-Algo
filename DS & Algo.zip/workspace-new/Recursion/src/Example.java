import java.util.*;
class Akhil{
	int a;
	Akhil(){
		int a;
		a=this.a;
		System.out.println("Hi");
	}
	public void method(){
		
		
		NavigableSet<Integer> hs=new TreeSet<>();
		hs.add(30);
		hs.add(20);
		hs.add(50);
		hs.add(10);
		hs.add(40);
		System.out.println(hs+""+hs.size());
	}
}

public class Example  {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//System.out.println(a());
		char[] ch={'a','b','c'};
		String s=ch.toString();
		System.out.println(s);
		Akhil a=new Akhil();
		a.method();
				
		
	}

}
