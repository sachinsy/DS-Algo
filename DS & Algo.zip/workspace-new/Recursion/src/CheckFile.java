import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.TreeMap;

public class CheckFile {

	public static void counter(String str){

		//Count of each char in given string
		char a[]=str.toCharArray();
		HashMap<Character,Integer> hmap=new HashMap<>();
		TreeMap<Character, Integer> tmap=new TreeMap<>();
		for(char ch:a){
			if(hmap.containsKey(ch)){
				hmap.put(ch,hmap.get(ch)+1);
			}
			else{
				hmap.put(ch, 1);
			}
		}
		for(Map.Entry<Character,Integer> entry : hmap.entrySet()){
			System.out.println(entry.getKey()+"\t"+entry.getValue());
		}

		//Remove duplicate string in given string array
		/*String []str1=str.split(" ");
		HashSet<String> hset=new HashSet<>();
		for(int i=0;i<str1.length;i++){
			hset.add(str1[i]);
		}
		System.out.println(hset);
		*/
	}
	public static void main(String args[]) throws IOException{
		counter("abbca");
		//String strArray="Sachin Yadav Sachin";
		//counter(strArray);
	}

}
