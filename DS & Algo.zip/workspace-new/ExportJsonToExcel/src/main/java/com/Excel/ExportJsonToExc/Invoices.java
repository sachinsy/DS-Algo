package com.Excel.ExportJsonToExc;
import java.util.*;

public class Invoices {

	private String Name;
	private Long Date;
	private Date LastModified;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Long getDate() {
		return Date;
	}
	public void setDate(Long date) {
		Date = date;
	}
	public Date getLastModified() {
		return LastModified;
	}
	public void setLastModified(Date lastModified) {
		LastModified = lastModified;
	}
	
	
	
}
