package com.Excel.ExportJsonToExcel;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ProgramJSONExample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		  String fileData = new String(Files.readAllBytes(Paths
		    .get("D:\\json2CSV\\demo.txt")));
		  JSONInfo jsonInfo = gson.fromJson(fileData, JSONInfo.class);
		  System.out.println(fileData);
		System.out.println(">>>>>>>>>>>>>>"+jsonInfo);
		  if (jsonInfo != null) {
		   writeExcel(jsonInfo); // Method to write data in excel
		  } else {
		   System.out.println("No data to write in excel, json is null or empty.");
		  }
		 }

		 /**
		  * Contract od this method is to write data into excel file
		  *
		  * @param jsonInfo
		  */
		 private static void writeExcel(JSONInfo jsonInfo) {

		  HSSFWorkbook hssfWorkbook = null;
		  HSSFRow row = null;
		  HSSFSheet hssfSheet = null;
		  FileOutputStream fileOutputStream = null;
		  Properties properties = null;
		  try {
		   String filename = "D:\\json2CSV\\demo.xls";
		   hssfWorkbook = new HSSFWorkbook();
		   hssfSheet = hssfWorkbook.createSheet("new sheet");

		   HSSFRow rowhead = hssfSheet.createRow((short) 0); // Header
		   rowhead.createCell((short) 0).setCellValue("SNo");
		   rowhead.createCell((short) 1).setCellValue(
		     "RegisteredForActualService");
		   rowhead.createCell((short) 2).setCellValue("EmsCreationTime");
		   rowhead.createCell((short) 3).setCellValue("RequestsOffering");
		   rowhead.createCell((short) 4).setCellValue("Record Type");
		   rowhead.createCell((short) 5).setCellValue("Related Properties");

		   int counter = 1;
		   System.out.println(jsonInfo.getRecords());
		   for (ProgramInfo programInfo : jsonInfo.getRecords()) {
			   
		    properties = programInfo.getProperties();
		    row = hssfSheet.createRow((short) counter);
		    row.createCell((short) 0).setCellValue(counter);
		    row.createCell((short) 1).setCellValue(
		      properties.getRegisteredForActualService());
		    row.createCell((short) 2).setCellValue(
		      properties.getEmsCreationTime());
		    row.createCell((short) 3).setCellValue(
		      properties.getRequestsOffering());
		    row.createCell((short) 4).setCellValue(
		      programInfo.getRecord_type());
		    row.createCell((short) 5).setCellValue("");// This is blank
		               // object without
		               // any property
		    counter++;
		   }
		   counter += 5;
		   row = hssfSheet.createRow((short) counter);
		   row.createCell((short) 0).setCellValue("Completion Status : "+
		     jsonInfo.getMeta().getCompletion_status());
		   row.createCell((short) 1).setCellValue("Total Count : "+
		     jsonInfo.getMeta().getTotal_count());

		   fileOutputStream = new FileOutputStream(filename);
		   hssfWorkbook.write(fileOutputStream);
		   fileOutputStream.close();
		   System.out.println("JSON data successfully exported to excel!");
		  } catch (Throwable throwable) {
		   System.out.println("Exception in writting data to excel : "
		     + throwable);
	}
		 }

}
