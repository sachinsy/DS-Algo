package com.Excel.ExportJsonToExc;

public class RestDetails {

	private Long CustomerNo;
	private Long MobileNo;
	private String Email;
	private Long Name;
	private Long LatestInvoice;
	private String id;
	public Long getCustomerNo() {
		return CustomerNo;
	}
	public void setCustomerNo(Long customerNo) {
		CustomerNo = customerNo;
	}
	public Long getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		MobileNo = mobileNo;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public Long getName() {
		return Name;
	}
	public void setName(Long name) {
		Name = name;
	}
	public Long getLatestInvoice() {
		return LatestInvoice;
	}
	public void setLatestInvoice(Long latestInvoice) {
		LatestInvoice = latestInvoice;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	
}
