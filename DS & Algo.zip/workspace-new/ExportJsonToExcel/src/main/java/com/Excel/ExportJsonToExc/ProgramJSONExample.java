package com.Excel.ExportJsonToExc;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.SpreadsheetVersion;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ProgramJSONExample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String fileData = new String(Files.readAllBytes(Paths.get("D:\\json2CSV\\25April.txt")));
		JSONInfo jsonInfo = gson.fromJson(fileData, JSONInfo.class);
		ProgramInfo pi;
		System.out.println(fileData);
	/*	//System.out.println(jsonInfo.getRecords());
		if(fileData.contains("Invoices: [")){
		
		}
		*/
		if (jsonInfo != null) {
			System.out.println("going to enter in method");
			writeExcel(jsonInfo); // Method to write data in excel
			System.out.println("executed method");
		} else {
			System.out.println("No data to write in excel, json is null or empty.");
		}
	}

	/**
	 * Contract od this method is to write data into excel file
	 *
	 * @param jsonInfo
	 */
	private static void writeExcel(JSONInfo jsonInfo) {

		HSSFWorkbook hssfWorkbook = null;
		HSSFRow row=null;
		HSSFSheet hssfSheet = null;
		FileOutputStream fileOutputStream = null;
		RestDetails properties = null;
	
		try {
			String filename = "D:\\json2CSV\\25April.xls";
			hssfWorkbook = new HSSFWorkbook();
			hssfSheet = hssfWorkbook.createSheet("new sheet");

			HSSFRow rowhead = hssfSheet.createRow((short) 0); // Header
			rowhead.createCell((short) 0).setCellValue("SNo");
			rowhead.createCell((short) 1).setCellValue("CustomerNo");
			rowhead.createCell((short) 2).setCellValue("MobileNo");
			rowhead.createCell((short) 3).setCellValue("Email");
			rowhead.createCell((short) 4).setCellValue("Name");
			rowhead.createCell((short) 5).setCellValue("Date");
			rowhead.createCell((short) 6).setCellValue("LastModified");
			rowhead.createCell((short) 7).setCellValue("Name");
			rowhead.createCell((short) 8).setCellValue("LatestInvoice");
			rowhead.createCell((short) 9).setCellValue("id");
			System.out.println("after printing header");
			int counter = 1;
			//System.out.println(jsonInfo.getRecords());
			for(ProgramInfo programInfo :jsonInfo.getRecords() ){
				properties =programInfo.getRestDetails();
				System.out.println("First phase me hi error hai");
				row.createCell((short) 0).setCellValue(counter);
				row.createCell((short) 1).setCellValue(
						properties.getCustomerNo());
				row.createCell((short) 2).setCellValue(
						properties.getMobileNo());
				row.createCell((short) 3).setCellValue(
						properties.getEmail());
				System.out.println("ProgramInfo me hai error");
		/*		row.createCell((short) 4).setCellValue(
						programInfo.getName());
				row.createCell((short) 5).setCellValue(
						programInfo.getDate());
				row.createCell((short) 6).setCellValue(
						programInfo.getLastModified());*/
				row.createCell((short) 7).setCellValue( 
						properties.getName());
				row.createCell((short) 8).setCellValue(
						properties.getLatestInvoice());
				row.createCell((short) 9).setCellValue(
						properties.getId());


				counter++;
			
			}
			System.out.println("after writing in excel file");
			/*  counter += 5;
		   row = hssfSheet.createRow((short) counter);
		   row.createCell((short) 0).setCellValue("Completion Status : "+
		     jsonInfo.getMeta().getCompletion_status());
		   row.createCell((short) 1).setCellValue("Total Count : "+
		     jsonInfo.getMeta().getTotal_count());*/

			fileOutputStream = new FileOutputStream(filename);
			hssfWorkbook.write(fileOutputStream);
			fileOutputStream.close();
			System.out.println("JSON data successfully exported to excel!");
		} catch (Throwable throwable) {
			System.out.println("Exception in writting data to excel : "
					+ throwable);
		}
	}

}
