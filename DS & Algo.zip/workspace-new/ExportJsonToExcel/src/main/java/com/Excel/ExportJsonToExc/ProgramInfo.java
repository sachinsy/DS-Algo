package com.Excel.ExportJsonToExc;

import java.util.Date;

public class ProgramInfo {
	//private Invoices invoices;
	private RestDetails restDetails;
	private String Name;
	private Long Date;
	private Date LastModified;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Long getDate() {
		return Date;
	}
	public void setDate(Long date) {
		Date = date;
	}
	public Date getLastModified() {
		return LastModified;
	}
	public void setLastModified(Date lastModified) {
		LastModified = lastModified;
	}

	/*public Invoices getInvoices() {
		return invoices;
	}
	public void setInvoices(Invoices invoices) {
		this.invoices = invoices;
	}*/
	public RestDetails getRestDetails() {
		return restDetails;
	}
	public void setRestDetails(RestDetails restDetails) {
		this.restDetails = restDetails;
	}
	
	

}
