package com.Excel.ExportJsonToExcel;

public class ProgramInfo {

	 private Properties properties;
	 private String record_type;
	 private RelatedObject related_properties;
	 public Properties getProperties() {
	  return properties;
	 }
	 public void setProperties(Properties properties) {
	  this.properties = properties;
	 }
	 public String getRecord_type() {
	  return record_type;
	 }
	 public void setRecord_type(String record_type) {
	  this.record_type = record_type;
	 }
	 public RelatedObject getRelated_properties() {
	  return related_properties;
	 }
	 public void setRelated_properties(RelatedObject related_properties) {
	  this.related_properties = related_properties;
	 }
}
