package com.Excel.ExportJsonToExcel;

import java.util.List;

public class JSONInfo {

	private List<ProgramInfo> records;
	 private MetaInfo meta;

	 public List<ProgramInfo> getRecords() {
	  return records;
	 }

	 public void setRecords(List<ProgramInfo> records) {
	  this.records = records;
	 }

	 public MetaInfo getMeta() {
	  return meta;
	 }

	 public void setMeta(MetaInfo meta) {
	  this.meta = meta;
	 }
}
