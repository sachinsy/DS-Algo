package com.Excel.ExportJsonToExcel;

public class Properties {

	private Long RegisteredForActualService;
	 private Long EmsCreationTime;
	 private Long RequestsOffering;
	 public Long getRegisteredForActualService() {
	  return RegisteredForActualService;
	 }
	 public void setRegisteredForActualService(Long registeredForActualService) {
	  RegisteredForActualService = registeredForActualService;
	 }
	 public Long getEmsCreationTime() {
	  return EmsCreationTime;
	 }
	 public void setEmsCreationTime(Long emsCreationTime) {
	  EmsCreationTime = emsCreationTime;
	 }
	 public Long getRequestsOffering() {
	  return RequestsOffering;
	 }
	 public void setRequestsOffering(Long requestsOffering) {
	  RequestsOffering = requestsOffering;
	 }
}
