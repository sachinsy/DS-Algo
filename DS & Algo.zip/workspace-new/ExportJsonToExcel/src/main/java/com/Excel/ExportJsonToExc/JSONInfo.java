package com.Excel.ExportJsonToExc;

import java.util.List;

public class JSONInfo {

	private List<ProgramInfo> records;

	public List<ProgramInfo> getRecords() {
		return records;
	}

	public void setRecords(List<ProgramInfo> records) {
		this.records = records;
	}
	
	
}
