package com.Excel.ExportJsonToExcel;

public class MetaInfo {

	private String completion_status;
	 private Long total_count;

	 public String getCompletion_status() {
	  return completion_status;
	 }

	 public void setCompletion_status(String completion_status) {
	  this.completion_status = completion_status;
	 }

	 public Long getTotal_count() {
	  return total_count;
	 }

	 public void setTotal_count(Long total_count) {
	  this.total_count = total_count;
	 }

}
