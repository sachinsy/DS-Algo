package com.Sachin.PracticeDemoHib;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="sachin_table")
public class login {

	@Id
	private int sid;
	private SachinName sname;
	private String color;
	
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}

	public SachinName getSname() {
		return sname;
	}
	public void setSname(SachinName sname) {
		this.sname = sname;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	@Override
	public String toString() {
		return "login [sid=" + sid + ", sname=" + sname + ", color=" + color + "]";
	}
	
	
	
}
