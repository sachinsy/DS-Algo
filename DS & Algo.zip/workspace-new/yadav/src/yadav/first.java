package yadav;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class first {
public static void main(String[] args) {
	Connection con=null;
	try{
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase","root","root");
	
/*	if(con!=null){
		System.out.println("Connected");
	}*/
	PreparedStatement ps=con.prepareStatement("INSERT INTO `loginuser`.`login` (`uid`, `uname`) VALUES ('3', 'Renu')");
	int result=ps.executeUpdate();
	if(result!=0){
		System.out.println("connection is formed");
		System.out.println("Data is inserted");
	}
	}
	catch(Exception e){
		System.out.println("Not Connected");
		System.out.println(e.getMessage());
	}
	}
}
