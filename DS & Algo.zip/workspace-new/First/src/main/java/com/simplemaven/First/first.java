package com.simplemaven.First;

import java.sql.Connection;
import java.sql.DriverManager;

public class first {
public static void main(String[] args) {
	Connection con=null;
	try{
		con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/loginuser","root","root");
		if(con!=null){
			System.out.println("Connected");
		}
		
	}
	catch(Exception e){
		System.out.println("Not Connected");
		System.out.println(e.getMessage());
	}
}
}
