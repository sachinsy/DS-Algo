package com.cache.Caching;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name="Person")
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY)
public class Person {
    
	@Id
	private int PID;
	private String Pname;
	private String Ploc;
	public int getPID() {
		return PID;
	}
	public void setPID(int pID) {
		PID = pID;
	}
	public String getPname() {
		return Pname;
	}
	public void setPname(String pname) {
		Pname = pname;
	}
	public String getPloc() {
		return Ploc;
	}
	public void setPloc(String ploc) {
		Ploc = ploc;
	}
	@Override
	public String toString() {
		return "Person [PID=" + PID + ", Pname=" + Pname + ", Ploc=" + Ploc + "]";
	}
	
	
	
}
