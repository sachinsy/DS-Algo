package com.cache.Caching;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.Service;
import org.hibernate.service.ServiceRegistry;

public class App 
{
    public static void main( String[] args )
    {
       
    	
    	
    	Configuration cf= new Configuration().configure();
    	ServiceRegistry sr=new StandardServiceRegistryBuilder().applySettings(cf.getProperties()).build();
    	//StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
    	//Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();  
        //SessionFactory factory=meta.getSessionFactoryBuilder().build();  
    	SessionFactory sf=cf.buildSessionFactory(sr);
    	Session session=sf.openSession();
    	Transaction tx=session.beginTransaction();
    	
    	Person p=new Person();
    	p.setPID(101);
    	p.setPname("ABC");
    	p.setPloc("Mumbai");
    	
    	
    	session.save(p);
    	session.close();
    	//tx.commit();
    	
    	Session s1=sf.openSession();
    	Person p1=new Person();
    	
    	p1=s1.get(Person.class, 101);
    	System.out.println(p1);
    	s1.close();
    	
    	Session s2=sf.openSession();
    	p1=s2.get(Person.class, 101);
    	System.out.println(p1);
    	s2.close();
    	
    	
    	
    	
    	
    	
    	

    }
}
