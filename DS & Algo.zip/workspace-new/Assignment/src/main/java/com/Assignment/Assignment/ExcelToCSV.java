package com.Assignment.Assignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList; 	
import java.util.List;
import java.util.Iterator;


import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelToCSV {
	//static String fileName;
	static int maxRows=2000;

	public static void ReportSplitter(String fileName,  int maxRows) throws InvalidFormatException {
		maxRows = maxRows;
		try {
			/* Read in the original Excel file. */
			//OPCPackage pkg = OPCPackage.open(new File(fileName));
			//Workbook wb = WorkbookFactory.create(pkg);
			/* int numberOfSheet = wb.getNumberOfSheets();*/
			//Workbook wb = WorkbookFactory.create(new File(fileName));
			//Sheet sheet = wb.getSheetAt(0);
			FileInputStream inputFile=new FileInputStream(new File(fileName));
			XSSFWorkbook workbook = new XSSFWorkbook(inputFile);
			XSSFSheet sheet = workbook.getSheetAt(0);
			// System.out.println(sheet.getPhysicalNumberOfRows());
			int noRows=sheet.getPhysicalNumberOfRows();
			/* Only split if there are more rows than the desired amount. */
			if  (noRows >= maxRows) {
				List<XSSFWorkbook> wbs = splitWorkbook(workbook);
				noRows=noRows-maxRows;
				writeWorkBooks(wbs);
			}
			inputFile.close();
		}
		catch (EncryptedDocumentException | IOException  e) {
			e.printStackTrace();
		}
	}



	public static List<XSSFWorkbook> splitWorkbook(XSSFWorkbook wb2) {

		List<XSSFWorkbook> workbooks = new ArrayList<XSSFWorkbook>();
		//List sheetData=new ArrayList<>();

		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sh = (XSSFSheet) wb.createSheet();

		XSSFRow newRow;
		XSSFCell newCell;

		int rowCount = 0;
		int colCount = 0;

		Sheet sheet = wb2.getSheetAt(0);	
		//sheet.createFreezePane(10, 4);
		/*Iterator<Row> rowIterator = sheet.iterator();
		while (rowIterator.hasNext()) 
		{
			Row row = rowIterator.next();
			//For each row, iterate through all the columns
			Iterator<Cell> cellIterator = row.cellIterator();
			List data = new ArrayList();
			while (cellIterator.hasNext()) {
				Cell cell = (Cell) cellIterator.next();
				data.add(cell);

			}
			sheetData.add(data);
		}

		DataFormatter formatter = new DataFormatter(); 
		for (int i = 0; i < sheetData.size(); i++) {
			List list = (List) sheetData.get(i);
			for (int j = 0; j < list.size(); j++) {
				Cell employeeid = (Cell) list.get(j);
				String j_username = formatter.formatCellValue(employeeid); 

				System.out.print(j_username);
				if (j < list.size() - 1) {
					System.out.print(", ");
				}
			}
			System.out.println("");
		}
		 */
		
/*		Object[][] headerData = { { "Version0", "Actual/Current Forecast/IFRS" }, { "Fiscal Year	2020" }, { "Period"	,"1"," To",	"12" },
				{ "Cost Center","	Activity Type","	Plan Activity",
			"Distribution key","	Capacity","	Capacity","	Plan Var. Price OCur","	Plan Fixed Price OCu" } } ;

		
		for (Object[] aBook : headerData) {
			Row row = sh.createRow(++rowCount);
			System.out.println("Row: " + row.getRowNum());
			int columnCount = 0;

			for (Object field : aBook) {
				Cell cell = row.createCell(++columnCount);
				if (field instanceof String) {
					cell.setCellValue((String) field);
				} else if (field instanceof Integer) {
					cell.setCellValue((Integer) field);
				}
			}

		}
		*/
		for (Row row : sheet) {
			newRow = (XSSFRow) sh.createRow(rowCount++);
			/* Time to create a new workbook? */
			//		copyRow(wb,sheet, 1, rowCount);
			if (rowCount == maxRows) {		
				workbooks.add(wb);
				wb = new XSSFWorkbook();
				sh = (XSSFSheet) wb.createSheet();
				//appendHeader(wb);
				rowCount = 0;
			}

			for (Cell cell : row) {
				newCell = (XSSFCell) newRow.createCell(colCount++);
				newCell = setValue(newCell, cell);
			}
			colCount = 0;
            //appendHeader(wb);
		}

		/* Only add the last workbook if it has content */
		if (wb.getSheetAt(0).getPhysicalNumberOfRows() > 0) {
			workbooks.add(wb);
		}
		return workbooks;
	}

	/*
	 * Grabbing cell contents can be tricky. We first need to determine what
	 * type of cell it is.
	 */ 
	public static XSSFCell setValue(XSSFCell newCell, Cell cell) {
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING: 
			newCell.setCellValue(cell.getRichStringCellValue().getString());
			break;
		case Cell.CELL_TYPE_NUMERIC:
			if (DateUtil.isCellDateFormatted(cell)) {
				newCell.setCellValue(cell.getDateCellValue());
			} else {
				newCell.setCellValue(cell.getNumericCellValue());
			}
			break;
		case Cell.CELL_TYPE_BOOLEAN:
			newCell.setCellValue(cell.getBooleanCellValue());
			break;
		case Cell.CELL_TYPE_FORMULA:
			newCell.setCellFormula(cell.getCellFormula());
			break;
		default:
			System.out.println("Could not determine cell type");
		}
		return newCell;
	}


	public static void appendHeader(XSSFWorkbook wb3){
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sh = (XSSFSheet) wb.createSheet();
		
		Object[][] headerData = { { "Version0", "Actual/Current Forecast/IFRS" }, { "Fiscal Year	2020" }, { "Period"	,"1"," To",	"12" },
				{ "Cost Center","	Activity Type","	Plan Activity",
			"Distribution key","	Capacity","	Capacity","	Plan Var. Price OCur","	Plan Fixed Price OCu" } } ;

		int rowc=0;
		for (Object[] aBook : headerData) {
			Row row = sh.createRow(++rowc);
			System.out.println("Row: " + row.getRowNum());
			int columnCount = 0;

			for (Object field : aBook) {
				Cell cell = row.createCell(++columnCount);
				if (field instanceof String) {
					cell.setCellValue((String) field);
				} else if (field instanceof Integer) {
					cell.setCellValue((Integer) field);
				}
			}

		}
	}

		/* Write all the workbooks to disk. */
		public static void writeWorkBooks(List<XSSFWorkbook> wbs) {
			FileOutputStream out;
			String fileName="C:\\Users\\sachiny\\Desktop\\SplittedFiles\\NewSplittedFile";
			try {
				for (int i = 0; i < wbs.size(); i++) {
					//String newFileName = fileName.substring(0, fileName.length() - 5);
					out = new FileOutputStream(new File(fileName + "_" + (i + 1) + ".xls"));
					wbs.get(i).write(out);
					out.close();
					System.out.println("File "+i+" created");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}  
		}

		public static void main(String[] args) throws InvalidFormatException{

			/* This will create a new workbook every 2000 rows. */
			ReportSplitter("C:\\Users\\sachiny\\Desktop\\USD-updatedNew.xlsx", 2000);
		}

	}