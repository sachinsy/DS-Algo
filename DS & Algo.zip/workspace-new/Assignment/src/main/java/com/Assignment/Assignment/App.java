package com.Assignment.Assignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class App {
	public static void main(final String args[]) throws IOException {
		App dm = new App();
		String file = "C:\\Users\\sachiny\\Desktop\\input.txt";
		int roll = 1;
		String rollnum = null;
		String outputfilename = null;

		boolean shouldContinue = true;

		try (BufferedReader br = new BufferedReader(new FileReader(file))) {

			while(shouldContinue){	
				rollnum = "file-00" + roll;
				outputfilename = "C:\\Users\\sachiny\\Desktop\\Output\\" + rollnum + ".txt";
				shouldContinue = dm.fillFile(outputfilename, br, 10);

				if(!shouldContinue){
					File f=new File(outputfilename);
					f.delete();
					break;
				}
				roll++;
			}
			//while (shouldContinue);

		} catch (FileNotFoundException e) {
			System.out.println("File not found");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/*	public void MaxOccur(String str){
		HashMap<String, Integer> hm=new HashMap<>();
		String a[]=str.split(" | ");
		for(String s:a){
			if(hm.get(s)!=null){
				hm.put(s, hm.get(s)+1);
			}
			else hm.put(s, 1);
		}
		Iterator<String> is=hm.keySet().iterator();
		while(is.hasNext()){
			String st=is.next();
			if(hm.get(str)>1){
				System.out.println("Character "+st+" has occurrence of "+hm.get(st));
			}

		}
	}*/


	private boolean fillFile(final String outputfilename, final BufferedReader reader, final int limit)
			throws IOException {

		int counter=0;
		boolean result = false;
		String line = null;
		BufferedWriter fbw = null;
		int temp = 0;
		try {
			OutputStreamWriter writer = new OutputStreamWriter(
					new FileOutputStream(outputfilename, true), "UTF-8");
			fbw = new BufferedWriter(writer);

			while (temp < limit && ((line = reader.readLine()) != null)) {

				temp++;

				//-------New changes---------


				int count=0;
				String s[]=new String[]{"T1","T2","T3","T4","T5","T6"};
				HashMap<String, Integer> hm=new HashMap<>();

				String a[]=line.split("\\|");

				for(int i=0;i<a.length;i++){
					System.out.print(a[i]);
					System.out.print("\t");
				}

				/*line.getBytes();
				Random rd=new Random();
				rd.nextBytes(line.getBytes());*/
				/*Scanner src=new Scanner(outputfilename);
				while(src.hasNext()){
					line=src.next();

				}*/
				//		----------	End Changes------------

				fbw.write(line);
				fbw.newLine();

			}

			// abort if we didn't manage to read the "limit" number of lines
			result = (temp == limit);


		} 
		catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		} 
		finally {
			fbw.close();
		}

		return result;
	}
}
