package com.TestJSch.CsvReaderSftp;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class TestJSch {
	static String directory = "D:/SampleCSV/";
	final static File folder = new File(directory);
	public static void main(String args[]) throws IOException {
		JSch jsch = new JSch();
		Session session = null;
		try {
			session = jsch.getSession("user", "127.0.0.1", 22);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword("password");
			session.connect();

			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			List<String> listFilesForFolder = listFilesForFolder(folder);
			
			for(String filename : listFilesForFolder){
				
				InputStream stream = sftpChannel.get(directory+filename);
			}
			
			InputStream stream = sftpChannel.get("D:/SampleCSV/testfile.txt");
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(stream));
				String line;
				while ((line = br.readLine()) != null) {
					System.out.println(line);
				}

			} catch (IOException io) {
				System.out.println("Exception occurred during reading file from SFTP server due to " + io.getMessage());
				io.getMessage();

			} catch (Exception e) {
				System.out.println("Exception occurred during reading file from SFTP server due to " + e.getMessage());
				e.getMessage();

			}

			sftpChannel.exit();
			session.disconnect();
		} catch (JSchException e) {
			e.printStackTrace();
		} catch (SftpException e) {
			e.printStackTrace();
		}
	}

	public static List<String> listFilesForFolder(final File folder) {
		List<String> list = new ArrayList<String>();

		for (final File fileEntry : folder.listFiles()) {

			if (fileEntry.isFile()) {

				list.add(fileEntry.getName());

			}

		}
		return list;

	}

	

	
}
