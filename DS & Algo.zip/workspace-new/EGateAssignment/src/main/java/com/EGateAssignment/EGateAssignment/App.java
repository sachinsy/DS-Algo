package com.EGateAssignment.EGateAssignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/*class FileRead{
	public void FileRead() throws Exception{
		int i;
		File f=new File("C:\\Users\\sachiny\\Desktop\\input.txt");
		FileReader fr=new FileReader(f);
		while((i=fr.read())!=-1){
			
			System.out.print((char)i);
		}
	}
}*/
public class App 
{
    public static void main( String[] args ) throws Exception
    {
    	Scanner s=new Scanner(System.in);
    	//FileRead fread=new FileRead();
    	//fread.FileRead();
    	App dm=new App();
    	 String file = "C:\\Users\\sachiny\\Desktop\\input.txt";
         int roll = 1;
         String rollnum = null;
         String outputfilename = null;

         boolean shouldContinue = false;

         try (FileReader fr=new FileReader("C:\\Users\\sachiny\\Desktop\\input.txt")) {

             do {

                 rollnum = "file-00" + roll;
                 outputfilename = "D:\\output\\" + rollnum + ".txt";
                 shouldContinue = dm.fillFile(outputfilename, br, 200);
                 roll++;
             } while (shouldContinue);

         } catch (FileNotFoundException e) {
             System.out.println("File not found");
             e.printStackTrace();
         } catch (IOException e) {
             // TODO Auto-generated catch block
             e.printStackTrace();
         }

     }

     private boolean fillFile(final String outputfilename, final BufferedReader reader, final int limit)
             throws IOException {

         boolean result = false;
         String line = null;
         BufferedWriter fbw = null;
         int temp = 0;
         try {
             OutputStreamWriter writer = new OutputStreamWriter(
                     new FileOutputStream(outputfilename, true), "UTF-8");
             fbw = new BufferedWriter(writer);

             while (temp < limit && ((line = reader.readLine()) != null)) {

                 temp++;
                 fbw.write(line);
                 fbw.newLine();

             }

             // abort if we didn't manage to read the "limit" number of lines
             result = (temp == limit);

         } catch (Exception e) {
             System.out.println("Error: " + e.getMessage());
         } finally {
             fbw.close();
         }

         return result;

     }
        
    }

