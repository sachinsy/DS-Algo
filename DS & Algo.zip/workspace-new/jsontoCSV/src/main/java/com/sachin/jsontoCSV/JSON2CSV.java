package com.sachin.jsontoCSV;

import java.io.BufferedReader;
import com.google.gson.JsonParser;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.json.Json;

import org.apache.commons.io.FileUtils;
import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MappingJsonFactory;
import com.fasterxml.jackson.databind.deser.ValueInstantiator.Gettable;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.github.wnameless.json.unflattener.JsonUnflattener;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
/*
class JsonToCSV{
	public void JsonToCSV(){
		JSONObject output;
		try {
			File file=new File("D:\\json2CSV\\demo.txt");
			BufferedReader reader=new BufferedReader(new FileReader(file));
			String json="";
			String line="";
			while((line=reader.readLine())!=null){
				json=json+"\n"+line;
			}
			System.out.println(json);
			output = new JSONObject(json);
			JSONArray docs = output.getJSONArray("demo");

			//  todays work
			ArrayList<String> listdata = new ArrayList<String>(); 
			if (docs != null) { 
				for (int i=0;i<docs.length();i++){ 
					listdata.add(docs.getString(i));
				} 
			}
			for(int i=0;i<listdata.size();i++)
				if(listdata.get(i).equals("Invoices")){
					System.out.println(listdata.get(i));
				}
			System.out.println(listdata);
			Gson gsonObj=new Gson();
			// gsonObj.toJsonTree(docs);
			//  JSONArray docs1 = output.getJSONArray("demo").get
			File file1=new File("D:\\json2CSV\\ConvertedJSON.csv");
			String  csv = gsonObj.toJsonTree(docs).toString();
			FileUtils.writeStringToFile(file1, csv);
			System.out.println("file exported");
			reader.close();
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}        
	}
}

 */
public class JSON2CSV {
	public static void main(String myHelpers[]) throws FileNotFoundException,IOException{


		JsonToCSV jcsv=new JsonToCSV();
		jcsv.JsonToCSV();

	}
}
class JsonToCSV{
	public static void JsonToCSV() throws IOException{
		JSONParser parser = new JSONParser();
		try {

			// Put above JSON content to crunchify.txt file and change path location
			String obj = parser.parse(new FileReader("D:\\json2CSV\\demo.txt")).toString();
			System.out.println(obj);
			
			JSONObject jsonObject =new JSONObject(obj);
			

			// JsonFlattener: A Java utility used to FLATTEN nested JSON objects
			String flattenedJson = JsonFlattener.flatten(jsonObject.toString());

			
			/*File file1=new File("D:\\json2CSV\\ConvertedJSON.csv");
			//JsonArray docs=jsonObject.getJsonAsArray("Demo");
		
			String  csv = CDL.toString(docs);
			FileUtils.writeStringToFile(file1,csv);*/
			
			//System.out.println("file exported");
			log("\n=====Simple Flatten===== \n" + flattenedJson);
			

			Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(jsonObject.toString());
 
			log("\n=====Flatten As Map=====\n" + flattenedJson);
			// We are using Java8 forEach loop. More info: http://crunchify.me/1VIwm0l
			flattenedJsonMap.forEach((k, v) -> log(k + " : " + v));
			
			
			JSONObject jsonObj =new JSONObject(flattenedJson);
			JSONArray docs = jsonObject.getJSONArray("demo");

			File file1=new File("D:\\json2CSV\\ConvertedJSON.csv");
			//JsonArray docs=jsonObject.getJsonAsArray("Demo");
		
			String  csv = CDL.toString(docs);
			FileUtils.writeStringToFile(file1,csv);
			System.out.println("file exported");

			// Unflatten it back to original JSON
			String nestedJson = JsonUnflattener.unflatten(flattenedJson);
			System.out.println("\n=====Unflatten it back to original JSON===== \n" + nestedJson);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void log(String flattenedJson) {
		System.out.println(flattenedJson);

	}
}

/*

File file1=new File("D:\\json2CSV\\ConvertedJSON.csv");
JsonArray docs=jobject.getAsJsonArray("Demo");
Gson gsonObj=new Gson();
String  csv = gsonObj.toJsonTree(docs).toString();
FileUtils.writeStringToFile(file1,csv);
System.out.println("file exported");*/
