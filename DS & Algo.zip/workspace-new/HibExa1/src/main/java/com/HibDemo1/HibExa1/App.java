package com.HibDemo1.HibExa1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class App {
	public static void main(String[] args) {

		
		Alien a = new Alien();
		a.setAid(105);
		a.setAname("Sachin");
		
		Laptop lp = new Laptop();
		lp.setLid(4);
		lp.setBrand("Samsung");
		lp.setPrice(500);
		lp.setAlien(a);

		
		Configuration conf = new Configuration().configure().addAnnotatedClass(Alien.class)
				.addAnnotatedClass(Laptop.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(conf.getProperties()).buildServiceRegistry();
		SessionFactory sf = conf.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		session.save(a);
		session.save(lp);
		tx.commit();
		System.out.println(a);
		System.out.println(lp);
	}
}
